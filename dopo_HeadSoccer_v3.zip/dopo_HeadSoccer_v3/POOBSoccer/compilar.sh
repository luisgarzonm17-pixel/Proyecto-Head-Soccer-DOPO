#!/bin/sh
# Compila y ejecuta POOBSoccer (requiere JDK 17 o superior)
set -e
mkdir -p out
javac -d out src/domain/*.java src/presentation/*.java test/domain/*.java
case "$1" in
  test) java -cp out domain.PruebasDominio ;;
  *)    java -cp out presentation.POOBSoccer ;;
esac
