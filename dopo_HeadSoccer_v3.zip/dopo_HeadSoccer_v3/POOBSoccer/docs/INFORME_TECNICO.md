# Informe técnico de modificaciones

## Alcance aplicado

Se corrigió el proyecto hasta los entregables de la **versión tres**:

1. Maqueta, presentación y dominio.
2. Persistencia y dominio.
3. Pruebas de aceptación posteriores a los entregables anteriores.

No se implementaron funcionalidades propias de la versión cuatro.

## Problemas encontrados

- La implementación incluía la modalidad Máquina vs Máquina.
- `Modalidad`, configuración, selección, partido, presentación y pruebas mantenían rutas MvsM.
- El proyecto indicaba que la persistencia estaba pendiente.
- La persistencia no existía en el dominio ni en el menú.
- Algunas reglas presentaban implementaciones sin responsabilidad concreta en sus hooks.

## Cambios realizados

- Se eliminó el valor `MVSM` de `Modalidad`.
- `Partido` crea un jugador humano en PvsP/PvsM y una máquina solo en el lado derecho de PvsM.
- Se retiró el caso MvsM de selección, configuración y envío de controles.
- Se creó `PersistenciaPartida` para guardar y abrir partidas iniciadas.
- Se agregó “Abrir partida” al menú principal y “Guardar partida” al menú de pausa.
- Se añadió restauración de marcador, balones, reloj, gol de oro, carga de poder, estado y posiciones.
- Los hooks de `ReglaPartido` quedaron definidos por cada regla.
- Se incorporó una prueba automática de guardado y apertura.

## Clases modificadas

- `Modalidad`: eliminación de MvsM.
- `Partido`: construcción correcta de controladores y restauración de estado.
- `Marcador`, `Jugador`, `ReglaPorTiempo`: restauración mínima.
- `ReglaPartido`, `ReglaPorGoles`, `ReglaPorTiempo`, `ReglaSupervivencia`: responsabilidades explícitas.
- `PanelConfiguracion`, `PanelSeleccion`, `PanelPartido`, `PanelMenu`, `VentanaPrincipal`, `Navegador`: modalidades y persistencia.
- `PruebasDominio`: eliminación de pruebas MvsM y prueba de persistencia.

## Clase creada

- `PersistenciaPartida`: lectura y escritura de un archivo `.poobsoccer` y reconstrucción de `Partido`.

## Funcionalidades eliminadas

Máquina vs Máquina fue eliminado por no pertenecer a los requisitos oficiales. También desaparecieron sus ramas de ejecución, su opción de configuración y sus pruebas.

## Mantenibilidad

- La persistencia está separada de Swing y puede probarse desde el dominio.
- La configuración sigue siendo un único `ConfigPartido`.
- La modalidad se valida en un enum reducido.
- Los estados restaurables se delegan a las reglas y al marcador.
