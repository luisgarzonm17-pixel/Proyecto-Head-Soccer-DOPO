# POOBSoccer – Diseño de Presentación y Dominio

## 1. Arquitectura

```
presentation ──usa──▶ domain          (domain NO conoce a presentation)
```

- **domain**: toda la lógica (física, reglas, poderes, IA). No importa `java.awt` ni `javax.swing`; por eso se puede probar sin pantalla (`PruebasDominio`).
- **presentation**: pantallas Swing. Solo traduce teclado → `Intencion`, llama a `Partido.actualizar(dt)` y dibuja lo que el dominio expone.
- Puente entre capas: `Partido.enviarIntencion(Lado, Intencion)` (entrada) y `PartidoListener` (salida: goles, poderes, fin).

## 2. Dominio (relación con el diagrama de clases del ciclo 0)

| Diagrama inicial | Dominio actual | Cambio |
|---|---|---|
| Partido (estado, iniciar, actualizar) | `Partido` + `EstadoPartido` | Orquesta física, reglas y eventos; añade pausar/reanudar |
| Marcador (golesP1…) | `Marcador` | Indexado por `Lado`; guarda goles **y** balones (supervivencia) |
| Personaje (nombre, pos, vel, dir, mover, saltar, patear) | `Personaje` (+ `FichaPersonaje`, `CatalogoPersonajes`) | Hereda de `Cuerpo`; efectos temporales; stats 1–5 |
| Balon (botar) | `Balon` | Física de gravedad; los rebotes los resuelve `Campo` |
| Porteria (lado, Hitbox) | `Porteria` + `Hitbox` | Detecta gol "completamente dentro" |
| SuperTiros / TipoPoder (energia, duracion, ejecutar) | `Poder` (abstracta) + `Congelacion`, `Reduccion`, `Confusion`, `Lentitud`; `TipoPoder` (fábrica) | Polimorfismo: cada poder define su efecto |
| jugadorLocal / jugadorVisitante | `Jugador` por `Lado` (IZQUIERDO/DERECHO) | El jugador tiene barra de poder y un `Controlador` |
| Vector | `Vector` (record) | Inmutable |
| EstadoPartido, Lado | enums del mismo nombre | — |

Clases nuevas: `Campo` (dimensiones y rebotes), `ReglaPartido` (+ `ReglaPorTiempo`, `ReglaPorGoles`, `ReglaSupervivencia`), `Controlador` (+ `ControladorHumano`, `ControladorMaquina`), `Modalidad`, `TipoPartido`, `Dificultad`, `ConfigPartido`, `SerieSupervivencia`, `TipoEfecto`, `POOBSoccerException`.

### Patrones usados
- **Strategy**: `ReglaPartido` (cómo termina el partido) y `Controlador` (humano o máquina). Agregar un tipo de partido o una IA nueva no toca `Partido`.
- **Observer**: `PartidoListener` avisa a la interfaz sin que el dominio la conozca.
- **Fábrica**: `TipoPoder.crear()`.

```mermaid
classDiagram
  class Partido
  class Campo
  class Marcador
  class Jugador
  class Personaje
  class Balon
  class Porteria
  class Cuerpo { <<abstract>> }
  class Poder { <<abstract>> }
  class ReglaPartido { <<abstract>> }
  class Controlador { <<interface>> }
  Partido *-- Campo
  Partido *-- Marcador
  Partido *-- Balon
  Partido *-- "2" Jugador
  Partido o-- ReglaPartido
  Campo *-- "2" Porteria
  Jugador *-- Personaje
  Jugador o-- Controlador
  Cuerpo <|-- Personaje
  Cuerpo <|-- Balon
  Poder <|-- Congelacion
  Poder <|-- Reduccion
  Poder <|-- Confusion
  Poder <|-- Lentitud
  ReglaPartido <|-- ReglaPorTiempo
  ReglaPartido <|-- ReglaPorGoles
  ReglaPartido <|-- ReglaSupervivencia
  Controlador <|.. ControladorHumano
  Controlador <|.. ControladorMaquina
```

## 3. Presentación

Flujo (basado en el boceto): **Menú → Configuración → Selección de personaje → Partido → (Pausa) → Resultado**.

| Clase | Pantalla |
|---|---|
| `VentanaPrincipal` (implementa `Navegador`) | Ventana con `CardLayout` |
| `PanelMenu`, `PanelControles` | Menú y tabla de controles |
| `PanelConfiguracion` | Modalidad (PvsP / PvsM), tipo de partido y meta de goles (3/5/7). Supervivencia solo se habilita en PvsM |
| `PanelSeleccion` | Personaje, nombre y dificultad de la máquina |
| `PanelPartido` | Cuenta regresiva, HUD (nombre, país, goles/balones, barra y poder activo, tiempo), avisos, pausa |
| `PanelResultado` | Ganador, marcador, revancha / siguiente rival |
| `Dibujante`, `Estilo`, `Paises` | Dibujo y estilo (los colores por país viven aquí, no en el dominio) |

## 4. Supuestos tomados (confirmar con el profesor)

1. **Poder**: con la barra llena, la tecla de poder lo *arma*; se dispara en el **siguiente golpe al balón** del jugador (contacto o patada) y afecta al oponente. El HUD muestra "(armado)".
2. **Aturdimiento**: una **patada que alcanza al rival** lo aturde 3 s (no se mueve, salta ni patea). Tras un aturdimiento/congelación hay 1,5 s de inmunidad para evitar encadenar. Congelación (3 s) inmoviliza igual que el aturdimiento.
3. **Supervivencia**: 3 balones por jugador; los rivales cambian en cada partido y la dificultad sube (Fácil → Medio → Difícil).
4. **Barra de poder**: se llena sola en 12 s. Los poderes duran 3 s (congelación) y 6 s (los demás).
5. **Autogol**: el gol cuenta para el lado contrario al arco donde entró el balón; el aviso lo indica.
6. **Gol de oro / muerte súbita**: se tratan como lo mismo (en el partido por tiempo, si hay empate).
7. En **PvsM** el humano es el Jugador 1 (izquierda) y puede usar cualquiera de los dos juegos de teclas.
8. Países y poderes del catálogo: Canadá–Congelación, Colombia–Reducción, Brasil–Confusión, México–Lentitud (agregar uno es una línea en `CatalogoPersonajes`).

## 5. Inconsistencias detectadas en los documentos (para decidir como equipo)

- **PDF**: la lista "Tipos de partido" solo incluye *Por goles* y *Supervivencia*, pero las reglas describen el partido *por tiempo* (60 s) y la propuesta menciona "por tiempo". Se implementaron los tres.
- **PDF**: "Reducción (C)" parece tener el país sin completar; se asignó Colombia. "Confusión" no indica país.
- **PDF**: el ganador "por goles o muerte súbita" y el "gol de oro" describen el mismo desempate.
- **Boceto**: muestra Torneo/Liga/Opciones/Arcade, botones táctiles JUMP/KICK y un panel de controles con la D repetida y sin tecla de poder. Eso es del Head Soccer original, no de POOBSoccer; la interfaz implementada sigue el PDF. Conviene **actualizar el boceto** (menú: Jugar/Controles/Salir; configuración con modalidad y tipo; HUD con barra de poder).
- **Diagrama de clases**: no tiene reglas de partido, controladores ni la modalidad; esta versión los agrega (ver §2).

## 6. Pruebas
`./compilar.sh test` ejecuta verificaciones: validaciones de configuración, estado inicial, gol y autogol, fin por goles, gol de oro, supervivencia, pausa, barra y poderes (congelación, reducción, confusión), aturdimiento por patada y persistencia.

## 7. Pendiente para siguientes entregas
Más países/poderes, sonido, ajuste fino de la IA y de la física, y el ciclo de vida de pruebas unitarias con JUnit si lo exige el curso.

## 8. Organización interna y guía de extensión

La aplicación está organizada en dos capas. `presentation` conoce a `domain`,
pero `domain` no conoce Swing. Esta regla debe conservarse: permite probar la
lógica sin abrir ventanas y evita que una decisión visual cambie las reglas
del juego.

### Responsabilidades principales

| Componente | Responsabilidad | Cuándo modificarlo |
|---|---|---|
| `Partido` | Fachada pública, estados, pausa, regla activa, marcador y eventos | Al cambiar el ciclo de vida o el flujo general |
| `MotorFisica` | Paso físico, movimiento, colisiones, patadas y detección de gol | Al cambiar rebotes, contactos o interacción física |
| `Campo` | Dimensiones, límites, porterías y rebotes del balón | Al cambiar la geometría de la cancha |
| `Personaje` | Movimiento individual, salto, patada y efectos temporales | Al cambiar estadísticas o estados de un personaje |
| `ReglaPartido` | Condición de finalización y ganador | Al crear un modo de partido |
| `Controlador` | Decisión de acciones de un jugador | Al crear una nueva forma de control o IA |
| `Poder` | Efecto especial aplicado al rival | Al agregar un poder |
| `PartidoListener` | Notificación de goles, poderes, estados y finalización | Al agregar eventos para la presentación |

`Partido` sigue siendo el punto de entrada para la presentación. La
refactorización interna no cambia sus métodos públicos: la interfaz continúa
siendo `iniciar`, `actualizar`, `pausar`, `reanudar`, `enviarIntencion` y sus
consultas. `MotorFisica` es deliberadamente una clase de paquete; no es una
abstracción que las pantallas deban conocer.

### Flujo de un paso de simulación

1. `Partido.actualizar(dt)` ignora el tiempo si el partido está pausado,
   terminado o en la celebración de un gol.
2. El tiempo se divide en pasos de como máximo `1/120` segundos para evitar
   que un `dt` grande atraviese cuerpos o porterías.
3. La regla activa avanza su reloj y puede finalizar el partido.
4. `MotorFisica` pide una `Intencion` a cada `Controlador`, actualiza los
   personajes y los contiene dentro de `Campo`.
5. Se separan los personajes si se superponen, se mueve el balón y se
   resuelven contacto, patada y aturdimiento.
6. `Campo` aplica rebotes y comprueba si el balón está completamente dentro de
   una portería.
7. `Partido` registra el gol, actualiza la regla, notifica a los observadores y
   comienza la celebración o termina el encuentro.

### Cómo agregar una regla de partido

1. Crear una subclase de `ReglaPartido`.
2. Implementar `iniciar`, `terminado`, `ganador` y `descripcion`; implementar
   `alAvanzar` o `alGol` solo si el modo lo necesita.
3. Agregar el valor correspondiente a `TipoPartido`.
4. Seleccionar la nueva regla en el `switch` del constructor de `Partido`.
5. Agregar pruebas de inicio, progreso, finalización y ganador en
   `test/domain/PruebasDominio.java`.

La regla no debe mover personajes ni conocer Swing. Solo debe consultar y
actualizar el `Marcador` y decidir cuándo termina el partido.

### Cómo agregar un poder

1. Crear una clase que extienda `Poder` y pasar al constructor el tipo, efecto
   y duración.
2. Agregar el valor en `TipoPoder` y su creación en `TipoPoder.crear()`.
3. Asociarlo a una `FichaPersonaje` en `CatalogoPersonajes`.
4. Verificar el efecto, su duración y su interacción con inmunidad en las
   pruebas del dominio.

El poder no debe modificar directamente la interfaz. `PartidoListener` ya
notifica su uso y `PanelPartido` decide cómo mostrarlo.

### Cómo agregar una IA o control

Implementar `Controlador.decidir(Partido, Jugador, double)`. La estrategia
puede consultar el estado público del partido, pero debe devolver solamente
una `Intencion`; no debe mover cuerpos directamente. Después se agrega la
selección del controlador en el lugar donde `Partido` crea los jugadores.

### Reglas para mantener la extensibilidad

- Mantener la física en `MotorFisica` y la geometría de cancha en `Campo`.
- Mantener la finalización en `ReglaPartido`, no en `MotorFisica`.
- Mantener poderes y efectos independientes de Swing.
- Preferir eventos nuevos en `PartidoListener` antes que llamadas directas a
  clases de `presentation`.
- Cuando una clase coordine demasiados detalles, extraer una responsabilidad
  interna sin romper los métodos públicos de `Partido`.
- Cada extensión debe incluir al menos una prueba de comportamiento observable.
