# Matriz de cumplimiento — versión tres

| Requisito | Ubicación | Implementación | Verificación |
|---|---|---|---|
| Estructura en presentación y dominio | `src/presentation`, `src/domain` | Presentación Swing independiente de la lógica central | Compilación correcta |
| Diagrama y documentación de clases | `docs/DISEÑO.md` | Arquitectura, relaciones y guía de extensión | Revisada |
| Configuración del juego | `PanelConfiguracion`, `ConfigPartido` | Modalidad, tipo de partido y meta de goles | Pruebas de configuración |
| Jugador vs Jugador | `Modalidad.PVSP`, `Partido` | Dos controladores humanos | Prueba PvsP |
| Jugador vs Máquina | `Modalidad.PVSM`, `ControladorMaquina` | Un humano y una máquina | Pruebas PvsM |
| Máquina vs Máquina | — | Eliminada completamente | Enum reducido a dos valores |
| Nivel básico | `ControladorMaquina`, `Dificultad` | Tres dificultades | Pruebas existentes |
| Personaje, selección y poderes | `CatalogoPersonajes`, `FichaPersonaje`, `Poder` | Cuatro personajes y poderes definidos | Pruebas de poderes |
| Partido por goles | `ReglaPorGoles` | Metas 3, 5 o 7 | Prueba superada |
| Partido por tiempo | `ReglaPorTiempo` | 60 segundos y gol de oro | Prueba superada |
| Supervivencia | `ReglaSupervivencia`, `SerieSupervivencia` | Tres balones y rivales sucesivos PvsM | Prueba superada |
| Controles de ambos jugadores | `PanelControles`, `PanelPartido` | Teclado y pausa | Implementación revisada |
| Pausa y resultado | `EstadoPartido`, `PanelPartido`, `PanelResultado` | Estados, marcador y opciones | Pruebas de pausa |
| Persistencia | `PersistenciaPartida`, `PanelMenu`, `PanelPartido` | Abrir desde el menú y guardar desde pausa | Prueba guardar/abrir superada |
| Pruebas de dominio | `test/domain/PruebasDominio.java` | Suite sin JUnit ni dependencias externas | 35 verificaciones correctas |
