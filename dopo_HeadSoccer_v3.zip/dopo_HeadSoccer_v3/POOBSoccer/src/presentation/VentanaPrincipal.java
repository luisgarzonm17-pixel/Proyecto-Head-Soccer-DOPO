package presentation;

import domain.Partido;
import domain.SerieSupervivencia;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import domain.PersistenciaPartida;
import domain.POOBSoccerException;

// Ventana única con un CardLayout; implementa la navegación entre pantallas. 
public class VentanaPrincipal extends JFrame implements Navegador {
    private final CardLayout cartas = new CardLayout();
    private final JPanel raiz = new JPanel(cartas);
    private final Seleccion seleccion = new Seleccion();
    private final PanelSeleccion panelSeleccion = new PanelSeleccion(this);
    private PanelPartido partidoActual;
    private Component dinamico;                 // pantalla de partido o de resultado en curso

    public VentanaPrincipal() {
        super("POOBSoccer");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        raiz.add(new PanelMenu(this), "menu");
        raiz.add(new PanelConfiguracion(this), "configuracion");
        raiz.add(panelSeleccion, "seleccion");
        raiz.add(new PanelControles(this), "controles");
        setContentPane(raiz);
        setMinimumSize(new Dimension(900, 620));
        setSize(1060, 700);
        setLocationRelativeTo(null);
    }

    @Override public Seleccion seleccion() { return seleccion; }

    @Override public void mostrarMenu() { detenerPartido(); cartas.show(raiz, "menu"); }
    @Override public void mostrarConfiguracion() { cartas.show(raiz, "configuracion"); }
    @Override public void mostrarSeleccion() { panelSeleccion.preparar(); cartas.show(raiz, "seleccion"); }
    @Override public void mostrarControles() { cartas.show(raiz, "controles"); }
    @Override public void abrirPartida() {
        JFileChooser selector = new JFileChooser();
        selector.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Partida POOBSoccer (*." + PersistenciaPartida.EXTENSION + ")",
                PersistenciaPartida.EXTENSION));
        if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            iniciarPartido(PersistenciaPartida.abrir(selector.getSelectedFile()), null);
        } catch (IOException | POOBSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo abrir", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override public void iniciarPartido(Partido partido, SerieSupervivencia serie) {
        detenerPartido();
        partidoActual = new PanelPartido(this, partido, serie);
        mostrarDinamico(partidoActual);
        partidoActual.arrancar();
    }

    @Override public void mostrarResultado(Partido partido, SerieSupervivencia serie) {
        detenerPartido();
        if (serie != null) serie.registrarResultado(partido);   // sube de nivel o termina la serie
        mostrarDinamico(new PanelResultado(this, partido, serie));
    }

    private void detenerPartido() {
        if (partidoActual != null) { partidoActual.detener(); partidoActual = null; }
    }

    private void mostrarDinamico(JPanel panel) {
        if (dinamico != null) raiz.remove(dinamico);
        dinamico = panel;
        raiz.add(panel, "dinamico");
        cartas.show(raiz, "dinamico");
        raiz.revalidate();
        raiz.repaint();
    }
}
