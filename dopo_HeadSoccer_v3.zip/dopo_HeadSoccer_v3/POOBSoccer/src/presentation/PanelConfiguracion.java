package presentation;

import domain.Modalidad;
import domain.TipoPartido;

import javax.swing.*;
import java.awt.*;
import java.util.EnumMap;
import java.util.Map;

// Elección de modalidad y tipo de partido. 
public class PanelConfiguracion extends JPanel {
    private final Navegador nav;
    private final Map<Modalidad, JRadioButton> modalidades = new EnumMap<>(Modalidad.class);
    private final Map<TipoPartido, JRadioButton> tipos = new EnumMap<>(TipoPartido.class);
    private final JComboBox<Integer> meta = new JComboBox<>(new Integer[]{3, 5, 7});
    private final JLabel ayuda = Estilo.etiqueta(" ", 15, Font.PLAIN, Estilo.SUAVE);

    public PanelConfiguracion(Navegador nav) {
        this.nav = nav;
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(Box.createVerticalGlue());
        add(centrado(Estilo.etiqueta("Configura el partido", 38, Font.BOLD, Estilo.ACENTO)));
        add(Box.createVerticalStrut(24));

        JPanel columnas = new JPanel(new GridLayout(1, 2, 30, 0));
        columnas.setOpaque(false);
        columnas.setMaximumSize(new Dimension(760, 230));
        columnas.add(grupo("Modalidad", modalidades, Modalidad.values()));
        JPanel derecha = grupo("Tipo de partido", tipos, TipoPartido.values());
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fila.setOpaque(false);
        fila.add(Estilo.etiqueta("Goles para ganar:", 16, Font.PLAIN, Color.WHITE));
        meta.setFont(Estilo.fuente(Font.BOLD, 16));
        fila.add(meta);
        derecha.add(fila);
        columnas.add(derecha);
        add(centrado(columnas));

        add(Box.createVerticalStrut(12));
        add(centrado(ayuda));
        add(Box.createVerticalStrut(24));
        add(Estilo.boton("Siguiente", this::continuar));
        add(Box.createVerticalStrut(12));
        add(Estilo.boton("Atrás", nav::mostrarMenu));
        add(Box.createVerticalGlue());

        for (JRadioButton b : modalidades.values()) b.addActionListener(e -> refrescar());
        for (JRadioButton b : tipos.values()) b.addActionListener(e -> refrescar());
        modalidades.get(Modalidad.PVSP).setSelected(true);
        tipos.get(TipoPartido.TIEMPO).setSelected(true);
        refrescar();
    }

    private <E extends Enum<E>> JPanel grupo(String titulo, Map<E, JRadioButton> mapa, E[] valores) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Estilo.PANEL);
        p.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        p.add(Estilo.etiqueta(titulo, 22, Font.BOLD, Color.WHITE));
        p.add(Box.createVerticalStrut(10));
        ButtonGroup bg = new ButtonGroup();
        for (E v : valores) {
            JRadioButton b = new JRadioButton(v.toString());
            b.setFont(Estilo.fuente(Font.PLAIN, 18));
            b.setForeground(Color.WHITE);
            b.setOpaque(false);
            b.setFocusable(false);
            bg.add(b);
            mapa.put(v, b);
            p.add(b);
            p.add(Box.createVerticalStrut(4));
        }
        return p;
    }

    // La supervivencia solo existe contra la máquina; la meta solo importa por goles. 
    private void refrescar() {
        boolean pvsm = modalidades.get(Modalidad.PVSM).isSelected();
        JRadioButton superv = tipos.get(TipoPartido.SUPERVIVENCIA);
        superv.setEnabled(pvsm);
        if (!pvsm && superv.isSelected()) tipos.get(TipoPartido.TIEMPO).setSelected(true);
        meta.setEnabled(tipos.get(TipoPartido.GOLES).isSelected());
        ayuda.setText(tipos.get(TipoPartido.SUPERVIVENCIA).isSelected()
                ? "Serie de partidos con 3 balones: cada gol le quita un balón al rival."
                : pvsm ? " " : "Dos jugadores en el mismo teclado.");
        if (!pvsm) superv.setToolTipText("Solo disponible en Jugador vs Máquina");
    }

    private void continuar() {
        Seleccion s = nav.seleccion();
        for (var e : modalidades.entrySet()) if (e.getValue().isSelected()) s.modalidad = e.getKey();
        for (var e : tipos.entrySet()) if (e.getValue().isSelected()) s.tipo = e.getKey();
        s.metaGoles = (Integer) meta.getSelectedItem();
        nav.mostrarSeleccion();
    }

    private static JComponent centrado(JComponent c) { c.setAlignmentX(Component.CENTER_ALIGNMENT); return c; }

    @Override protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondo(g, getWidth(), getHeight());
        g.dispose();
    }
}
