package presentation;

import domain.*;

import javax.swing.*;
import java.awt.*;

// Fin del partido: ganador, marcador y opciones para continuar. 
public class PanelResultado extends JPanel {
    private final Partido partido;

    public PanelResultado(Navegador nav, Partido partido, SerieSupervivencia serie) {
        this.partido = partido;
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        Lado ganador = partido.ganador();
        Marcador m = partido.marcador();

        add(Box.createVerticalGlue());
        add(centrado(Estilo.etiqueta("¡Ganador!", 48, Font.BOLD, Estilo.ACENTO)));
        add(Box.createVerticalStrut(10));
        add(centrado(Estilo.etiqueta(ganador == null ? "Empate" : partido.jugador(ganador).nombre()
                + " (" + partido.jugador(ganador).personaje().pais() + ")", 26, Font.BOLD, Color.WHITE)));
        add(Box.createVerticalStrut(190));          // espacio para las cabezas pintadas
        add(centrado(Estilo.etiqueta(m.goles(Lado.IZQUIERDO) + " – " + m.goles(Lado.DERECHO), 56, Font.BOLD, Color.WHITE)));
        add(Box.createVerticalStrut(6));
        add(centrado(Estilo.etiqueta(partido.golDeOro() ? "Definido por gol de oro" : partido.descripcionRegla(), 16, Font.PLAIN, Estilo.SUAVE)));
        add(Box.createVerticalStrut(26));

        if (serie != null) {
            if (!serie.terminada()) {
                add(centrado(Estilo.etiqueta("Victorias seguidas: " + serie.victorias(), 20, Font.BOLD, Estilo.ACENTO)));
                add(Box.createVerticalStrut(14));
                add(Estilo.boton("Siguiente rival", () -> nav.iniciarPartido(serie.nuevoPartido(), serie)));
            } else {
                add(centrado(Estilo.etiqueta("Fin de la serie · victorias seguidas: " + serie.victorias(), 20, Font.BOLD, Estilo.ACENTO)));
                add(Box.createVerticalStrut(14));
                add(Estilo.boton("Nueva serie", () -> nav.iniciarPartido(
                        new SerieSupervivencia(partido.config().nombreIzquierdo(), partido.config().fichaIzquierdo()).nuevoPartido(), null)));
            }
        } else {
            add(Estilo.boton("Revancha", () -> nav.iniciarPartido(new Partido(partido.config()), null)));
        }
        add(Box.createVerticalStrut(12));
        add(Estilo.boton("Volver al menú", nav::mostrarMenu));
        add(Box.createVerticalGlue());
    }

    private static JComponent centrado(JComponent c) { c.setAlignmentX(Component.CENTER_ALIGNMENT); return c; }

    @Override protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        Estilo.fondo(g, getWidth(), getHeight());
        double cx = getWidth() / 2.0, cy = getHeight() / 2.0 - 40;
        Lado ganador = partido.ganador();
        for (Lado l : Lado.values()) {
            Personaje p = partido.jugador(l).personaje();
            double r = l == ganador ? 62 : 46;
            Dibujante.cabeza(g, cx + (l == Lado.IZQUIERDO ? -150 : 150), cy + (l == ganador ? 0 : 14), r, p.pais(), -l.direccionAtaque());
        }
        g.dispose();
    }
}
