package presentation;

import domain.Modalidad;
import domain.TipoPartido;

// Opciones elegidas por el usuario mientras navega por las pantallas de configuración. 
public class Seleccion {
    public Modalidad modalidad = Modalidad.PVSP;
    public TipoPartido tipo = TipoPartido.TIEMPO;
    public int metaGoles = 3;
}
