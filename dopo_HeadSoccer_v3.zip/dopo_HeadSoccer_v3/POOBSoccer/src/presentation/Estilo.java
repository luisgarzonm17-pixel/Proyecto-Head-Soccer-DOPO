package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

// Colores, fuentes y componentes con el estilo del juego. 
final class Estilo {
    static final Color FONDO = new Color(0x0E1A2B), PANEL = new Color(0x16283F), ACENTO = new Color(0xFFC93C),
            VERDE = new Color(0x2FA84F), SUAVE = new Color(0xA9B7C9), TEXTO = Color.WHITE;

    private Estilo() {}

    static Font fuente(int estilo, float tam) { return new Font("SansSerif", estilo, 12).deriveFont(estilo, tam); }

    static void fondo(Graphics2D g, int w, int h) {
        g.setPaint(new GradientPaint(0, 0, new Color(0x0A1424), 0, h, new Color(0x1B3A5C)));
        g.fillRect(0, 0, w, h);
        g.setColor(new Color(255, 255, 255, 12));
        g.fillOval(-w / 6, h - h / 3, w / 2, w / 2);
        g.fillOval(w - w / 3, -h / 4, w / 2, w / 2);
    }

    static void suavizar(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    static JLabel etiqueta(String texto, float tam, int estilo, Color color) {
        JLabel l = new JLabel(texto);
        l.setFont(fuente(estilo, tam));
        l.setForeground(color);
        return l;
    }

    static BotonRedondo boton(String texto, Runnable accion) {
        BotonRedondo b = new BotonRedondo(texto);
        b.addActionListener(e -> accion.run());
        return b;
    }

    // Botón redondeado que se ve igual en todos los sistemas operativos. 
    static final class BotonRedondo extends JButton {
        BotonRedondo(String texto) {
            super(texto);
            setFont(fuente(Font.BOLD, 18));
            setForeground(FONDO);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(260, 46));
            setMaximumSize(new Dimension(260, 46));
            setAlignmentX(Component.CENTER_ALIGNMENT);
            setFocusable(false);   // el teclado es del juego
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            suavizar(g);
            Color base = !isEnabled() ? new Color(0x5A6677) : getModel().isPressed() ? ACENTO.darker()
                       : getModel().isRollover() ? new Color(0xFFE08A) : ACENTO;
            g.setColor(new Color(0, 0, 0, 70));
            g.fill(new RoundRectangle2D.Double(2, 4, getWidth() - 4, getHeight() - 5, 18, 18));
            g.setColor(base);
            g.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 2, getHeight() - 4, 18, 18));
            g.setFont(getFont());
            g.setColor(isEnabled() ? FONDO : new Color(0xC9D1DC));
            FontMetrics fm = g.getFontMetrics();
            g.drawString(getText(), (getWidth() - 2 - fm.stringWidth(getText())) / 2,
                    (getHeight() - 4 - fm.getHeight()) / 2 + fm.getAscent());
            g.dispose();
        }
    }
}
