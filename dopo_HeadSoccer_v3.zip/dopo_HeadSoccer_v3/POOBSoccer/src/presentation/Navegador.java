package presentation;

import domain.Partido;
import domain.SerieSupervivencia;

// Lo que las pantallas necesitan de la ventana principal (las desacopla de JFrame). 
public interface Navegador {
    Seleccion seleccion();
    void mostrarMenu();
    void mostrarConfiguracion();
    void mostrarSeleccion();
    void mostrarControles();
    // Abre el cuadro de archivos y carga una partida guardada. 
    void abrirPartida();
    void iniciarPartido(Partido partido, SerieSupervivencia serie);
    void mostrarResultado(Partido partido, SerieSupervivencia serie);
}
