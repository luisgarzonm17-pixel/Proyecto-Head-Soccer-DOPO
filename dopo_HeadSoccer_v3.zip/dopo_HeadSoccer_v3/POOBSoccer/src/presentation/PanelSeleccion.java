package presentation;

import domain.*;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

// Selección de personaje (y nombre) para cada lado. 
public class PanelSeleccion extends JPanel {
    private final Navegador nav;
    private final List<FichaPersonaje> fichas = CatalogoPersonajes.todos();
    private Selector izquierdo, derecho;
    private final JComboBox<Dificultad> dificultad = new JComboBox<>(Dificultad.values());
    private final JPanel centro = new JPanel(new GridBagLayout());
    private final JPanel pie = new JPanel();

    public PanelSeleccion(Navegador nav) {
        this.nav = nav;
        setOpaque(false);
        setLayout(new BorderLayout());
        JLabel titulo = Estilo.etiqueta("Elige tu personaje", 38, Font.BOLD, Estilo.ACENTO);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setBorder(BorderFactory.createEmptyBorder(24, 0, 8, 0));
        add(titulo, BorderLayout.NORTH);
        centro.setOpaque(false);
        add(centro, BorderLayout.CENTER);
        pie.setOpaque(false);
        pie.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 14));
        dificultad.setSelectedItem(Dificultad.MEDIO);
        dificultad.setFont(Estilo.fuente(Font.BOLD, 16));
        add(pie, BorderLayout.SOUTH);
    }

    // Se llama cada vez que se muestra la pantalla, porque depende de lo elegido antes. 
    public void preparar() {
        Seleccion s = nav.seleccion();
        boolean humanoIzq = s.modalidad.cantidadHumanos() >= 1, humanoDer = s.modalidad.cantidadHumanos() >= 2;
        boolean supervivencia = s.tipo == TipoPartido.SUPERVIVENCIA;

        centro.removeAll();
        izquierdo = new Selector(Lado.IZQUIERDO, humanoIzq, humanoIzq ? "Jugador 1" : "Máquina 1", 0);
        derecho = new Selector(Lado.DERECHO, humanoDer, s.modalidad == Modalidad.PVSP ? "Jugador 2" : "Máquina", 1);
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0; c.weighty = 1; c.fill = GridBagConstraints.VERTICAL; c.insets = new Insets(0, 14, 0, 14);
        centro.add(izquierdo, c);
        centro.add(Estilo.etiqueta("VS", 44, Font.BOLD, Color.WHITE), c);
        centro.add(supervivencia ? rivalesSupervivencia() : derecho, c);

        pie.removeAll();
        if (s.modalidad != Modalidad.PVSP && !supervivencia) {
            pie.add(Estilo.etiqueta("Dificultad de la máquina:", 16, Font.PLAIN, Color.WHITE));
            pie.add(dificultad);
        }
        pie.add(Estilo.boton("Atrás", nav::mostrarConfiguracion));
        pie.add(Estilo.boton("¡Jugar!", this::jugar));
        revalidate();
        repaint();
    }

    private JComponent rivalesSupervivencia() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Estilo.PANEL);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        p.setPreferredSize(new Dimension(320, 340));
        p.add(Estilo.etiqueta("Rivales", 24, Font.BOLD, Color.WHITE));
        p.add(Box.createVerticalStrut(10));
        for (int i = 0; i < fichas.size(); i++)
            p.add(Estilo.etiqueta((i + 1) + ". " + fichas.get(i).nombre() + " (" + fichas.get(i).pais() + ")", 16, Font.PLAIN, Estilo.SUAVE));
        p.add(Box.createVerticalStrut(14));
        p.add(Estilo.etiqueta("<html>Enfrentas a la máquina<br>una vez tras otra. Cada<br>victoria sube la dificultad.</html>", 15, Font.PLAIN, Color.WHITE));
        return p;
    }

    private void jugar() {
        Seleccion s = nav.seleccion();
        try {
            if (s.tipo == TipoPartido.SUPERVIVENCIA) {
                SerieSupervivencia serie = new SerieSupervivencia(izquierdo.nombre(), izquierdo.ficha());
                nav.iniciarPartido(serie.nuevoPartido(), serie);
            } else {
                ConfigPartido cfg = new ConfigPartido(s.modalidad, s.tipo, s.metaGoles,
                        izquierdo.nombre(), izquierdo.ficha(), derecho.nombre(), derecho.ficha(),
                        (Dificultad) dificultad.getSelectedItem());
                nav.iniciarPartido(new Partido(cfg), null);
            }
        } catch (POOBSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se puede iniciar", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Tarjeta de un lado: flechas, vista del personaje y nombre. 
    private final class Selector extends JPanel {
        private final Lado lado;
        private final boolean humano;
        private final JTextField nombre = new JTextField(12);
        private int indice;

        Selector(Lado lado, boolean humano, String nombreInicial, int indice) {
            this.lado = lado; this.humano = humano; this.indice = indice;
            setOpaque(false);
            setLayout(new BorderLayout(0, 8));
            setPreferredSize(new Dimension(380, 420));

            JLabel quien = Estilo.etiqueta(lado == Lado.IZQUIERDO ? "Jugador 1" : "Jugador 2", 22, Font.BOLD, Estilo.ACENTO);
            quien.setHorizontalAlignment(SwingConstants.CENTER);
            add(quien, BorderLayout.NORTH);

            JPanel fila = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
            fila.setOpaque(false);
            fila.add(flecha(-1));
            Vista vista = new Vista();
            vista.setPreferredSize(new Dimension(250, 340));
            fila.add(vista);
            fila.add(flecha(1));
            add(fila, BorderLayout.CENTER);

            JPanel sur = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            sur.setOpaque(false);
            nombre.setText(nombreInicial);
            nombre.setFont(Estilo.fuente(Font.BOLD, 16));
            nombre.setHorizontalAlignment(JTextField.CENTER);
            nombre.setEnabled(humano);
            sur.add(nombre);
            JLabel control = Estilo.etiqueta(humano ? teclas() : "Controlado por la máquina", 13, Font.PLAIN, Estilo.SUAVE);
            JPanel abajo = new JPanel(new GridLayout(2, 1));
            abajo.setOpaque(false);
            abajo.add(sur);
            control.setHorizontalAlignment(SwingConstants.CENTER);
            abajo.add(control);
            add(abajo, BorderLayout.SOUTH);
        }

        private String teclas() {
            boolean unico = nav.seleccion().modalidad == Modalidad.PVSM;
            if (unico) return "A D W S Q  o  ← → ↑ ↓ Ctrl der";
            return lado == Lado.IZQUIERDO ? "A D mover · W saltar · S patear · Q poder"
                                          : "← → mover · ↑ saltar · ↓ patear · Ctrl der poder";
        }

        private JButton flecha(int paso) {
            JButton b = new JButton() {
                @Override protected void paintComponent(Graphics g0) {
                    Graphics2D g = (Graphics2D) g0.create();
                    Estilo.suavizar(g);
                    g.setColor(getModel().isPressed() ? Estilo.ACENTO.darker() : Estilo.ACENTO);
                    g.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                    g.setColor(Estilo.FONDO);
                    int cx = getWidth() / 2, cy = getHeight() / 2, d = paso;
                    g.fillPolygon(new int[]{cx + 6 * d, cx - 6 * d, cx - 6 * d}, new int[]{cy, cy - 9, cy + 9}, 3);
                    g.dispose();
                }
            };
            b.setPreferredSize(new Dimension(40, 40));
            b.setFocusable(false);
            b.setContentAreaFilled(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> { indice = Math.floorMod(indice + paso, fichas.size()); repaint(); });
            return b;
        }

        FichaPersonaje ficha() { return fichas.get(indice); }
        String nombre() { return nombre.getText().trim(); }

        private final class Vista extends JComponent {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Estilo.suavizar(g);
                FichaPersonaje f = ficha();
                g.setColor(Estilo.PANEL);
                g.fill(new RoundRectangle2D.Double(4, 0, getWidth() - 8, getHeight(), 26, 26));
                double cx = getWidth() / 2.0;
                Dibujante.cabeza(g, cx, 78, 54, f.pais(), lado.direccionAtaque());
                g.setFont(Estilo.fuente(Font.BOLD, 22));
                centrar(g, f.nombre(), cx, 168, Color.WHITE);
                g.setFont(Estilo.fuente(Font.PLAIN, 16));
                centrar(g, f.pais(), cx, 190, Estilo.SUAVE);
                barra(g, "Velocidad", f.velocidad(), 220);
                barra(g, "Salto", f.salto(), 248);
                barra(g, "Fuerza", f.fuerza(), 276);
                g.setFont(Estilo.fuente(Font.BOLD, 16));
                centrar(g, "Poder: " + f.poder().etiqueta(), cx, 322, Estilo.ACENTO);
                g.dispose();
            }
            private void barra(Graphics2D g, String texto, int valor, int y) {
                g.setFont(Estilo.fuente(Font.PLAIN, 14));
                g.setColor(Color.WHITE);
                g.drawString(texto, 16, y + 11);
                for (int i = 0; i < 5; i++) {
                    g.setColor(i < valor ? Estilo.VERDE : new Color(255, 255, 255, 40));
                    g.fill(new RoundRectangle2D.Double(96 + i * 26, y, 22, 14, 6, 6));
                }
            }
            private void centrar(Graphics2D g, String t, double cx, double y, Color c) {
                g.setColor(c);
                g.drawString(t, (float) (cx - g.getFontMetrics().stringWidth(t) / 2.0), (float) y);
            }
        }
    }

    @Override protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondo(g, getWidth(), getHeight());
        g.dispose();
    }
}
