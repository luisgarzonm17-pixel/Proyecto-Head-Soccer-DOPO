package presentation;

import domain.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// Pantalla del partido: lee el teclado, hace avanzar el dominio y dibuja el resultado. 
public class PanelPartido extends JPanel {
    private static final double SEG_CUENTA = 3.0, SEG_FIN = 2.0, SEG_AVISO = 2.2;

    private final Navegador nav;
    private final Partido partido;
    private final SerieSupervivencia serie;
    private final Set<Integer> teclas = new HashSet<>();
    private boolean ctrlDerecho;
    private final Timer reloj;
    private long ultimo;
    private double cuenta = SEG_CUENTA, retardoFin = SEG_FIN;
    private boolean terminado;
    private final List<Aviso> avisos = new ArrayList<>();
    private final List<BotonPausa> botonesPausa = new ArrayList<>();
    private AffineTransform aPantalla = new AffineTransform();

    private record BotonPausa(String texto, RoundRectangle2D forma, Runnable accion) {}
    private static final class Aviso { final String texto; double restante = SEG_AVISO; Aviso(String t) { texto = t; } }

    public PanelPartido(Navegador nav, Partido partido, SerieSupervivencia serie) {
        this.nav = nav; this.partido = partido; this.serie = serie;
        if (partido.estado() != EstadoPartido.PREPARADO) cuenta = 0;
        setFocusable(true);
        setPreferredSize(new Dimension(1000, 600));
        partido.agregarOyente(new PartidoListener() {
            @Override public void alGol(Lado anotador) {
                Jugador a = partido.jugador(anotador);
                boolean autogol = partido.ultimoToque() == anotador.opuesto();
                avisar(autogol ? "¡Autogol! Punto para " + a.nombre() : "¡GOL de " + a.nombre() + "!");
            }
            @Override public void alUsarPoder(Jugador j, Poder p) { avisar(j.nombre() + " usa " + p.nombre()); }
            @Override public void alTerminar(Lado ganador) { repaint(); }
            @Override public void alCambiarEstado(EstadoPartido estado) { repaint(); }
        });
        configurarTeclado();
        configurarRaton();
        reloj = new Timer(16, e -> avanzar());
    }

    // ---------- ciclo ----------
    public void arrancar() {
        ultimo = System.nanoTime();
        reloj.start();
        requestFocusInWindow();
    }
    public void detener() { reloj.stop(); }

    private void avanzar() {
        long ahora = System.nanoTime();
        double dt = Math.min(0.05, (ahora - ultimo) / 1e9);
        ultimo = ahora;
        avisos.removeIf(a -> (a.restante -= dt) <= 0);

        if (cuenta > 0) {
            cuenta -= dt;
            if (cuenta <= 0) partido.iniciar();
        } else {
            enviarIntenciones();
            partido.actualizar(dt);
            if (partido.estado() == EstadoPartido.TERMINADO && !terminado) {
                terminado = true;
                Lado g = partido.ganador();
                avisar(g == null ? "Fin del partido" : "¡Ganó " + partido.jugador(g).nombre() + "!");
            }
            if (terminado && (retardoFin -= dt) <= 0) {
                detener();
                nav.mostrarResultado(partido, serie);
                return;
            }
        }
        repaint();
    }

    private void avisar(String texto) { avisos.add(new Aviso(texto)); }

    // ---------- entrada ----------
    private boolean k(int codigo) { return teclas.contains(codigo); }

    private void enviarIntenciones() {
        Intencion j1 = new Intencion(k(KeyEvent.VK_A), k(KeyEvent.VK_D), k(KeyEvent.VK_W), k(KeyEvent.VK_S), k(KeyEvent.VK_Q));
        Intencion j2 = new Intencion(k(KeyEvent.VK_LEFT), k(KeyEvent.VK_RIGHT), k(KeyEvent.VK_UP), k(KeyEvent.VK_DOWN), ctrlDerecho);
        switch (partido.config().modalidad()) {
            case PVSP -> { partido.enviarIntencion(Lado.IZQUIERDO, j1); partido.enviarIntencion(Lado.DERECHO, j2); }
            // Con un solo humano se aceptan ambos juegos de teclas para mayor comodidad.
            case PVSM -> partido.enviarIntencion(Lado.IZQUIERDO, j1.combinar(j2));
        }
    }

    private void configurarTeclado() {
        addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_CONTROL) { if (e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT) ctrlDerecho = true; return; }
                if ((e.getKeyCode() == KeyEvent.VK_P || e.getKeyCode() == KeyEvent.VK_ESCAPE) && !teclas.contains(e.getKeyCode())) alternarPausa();
                teclas.add(e.getKeyCode());
            }
            @Override public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_CONTROL) { if (e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT) ctrlDerecho = false; return; }
                teclas.remove(e.getKeyCode());
            }
        });
        addFocusListener(new FocusAdapter() {
            @Override public void focusLost(FocusEvent e) { teclas.clear(); ctrlDerecho = false; }
        });
    }

    private void configurarRaton() {
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                if (partido.estado() != EstadoPartido.PAUSADO) return;
                try {
                    Point2D p = aPantalla.inverseTransform(e.getPoint(), null);
                    for (BotonPausa b : botonesPausa) if (b.forma().contains(p)) { b.accion().run(); return; }
                } catch (java.awt.geom.NoninvertibleTransformException ignorada) {
                    // La transformación se creó con la misma escala usada para dibujar; si no puede invertirse, se ignora el clic.
                }
            }
        });
    }

    private void alternarPausa() {
        switch (partido.estado()) {
            case JUGANDO, GOL -> partido.pausar();
            case PAUSADO -> partido.reanudar();
            default -> { }
        }
        repaint();
    }

    // ---------- dibujo ----------
    @Override protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.suavizar(g);
        g.setColor(Estilo.FONDO);
        g.fillRect(0, 0, getWidth(), getHeight());
        double s = Math.min(getWidth() / Campo.ANCHO, getHeight() / Campo.ALTO);
        g.translate((getWidth() - Campo.ANCHO * s) / 2, (getHeight() - Campo.ALTO * s) / 2);
        g.scale(s, s);
        aPantalla = g.getTransform();
        g.setClip(0, 0, (int) Campo.ANCHO, (int) Campo.ALTO);

        Dibujante.cancha(g);
        for (Lado l : Lado.values()) Dibujante.arco(g, partido.campo().porteria(l));
        Dibujante.balon(g, partido.balon());
        for (Lado l : Lado.values()) Dibujante.personaje(g, partido.jugador(l));
        dibujarHud(g);
        dibujarAvisos(g);
        if (cuenta > 0) dibujarCuenta(g);
        if (partido.estado() == EstadoPartido.PAUSADO) dibujarPausa(g);
        g.dispose();
    }

    private void dibujarHud(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, (int) Campo.ANCHO, 92);
        dibujarBloqueJugador(g, partido.jugador(Lado.IZQUIERDO), 20, false);
        dibujarBloqueJugador(g, partido.jugador(Lado.DERECHO), Campo.ANCHO - 20, true);

        Marcador m = partido.marcador();
        String marcador = m.goles(Lado.IZQUIERDO) + " – " + m.goles(Lado.DERECHO);
        g.setFont(Estilo.fuente(Font.BOLD, 46));
        centrar(g, marcador, Campo.ANCHO / 2, 50, Color.WHITE);

        String centro;
        if (partido.golDeOro()) centro = "GOL DE ORO";
        else if (partido.tiempoRestante() >= 0) {
            int seg = (int) Math.ceil(partido.tiempoRestante());
            centro = String.format("%02d:%02d", seg / 60, seg % 60);
        } else centro = serie != null ? "Nivel " + serie.nivel() : partido.descripcionRegla();
        g.setFont(Estilo.fuente(Font.BOLD, 20));
        centrar(g, centro, Campo.ANCHO / 2, 80, partido.golDeOro() ? Estilo.ACENTO : Estilo.SUAVE);
    }

    private void dibujarBloqueJugador(Graphics2D g, Jugador j, double x, boolean derecha) {
        g.setFont(Estilo.fuente(Font.BOLD, 20));
        String titulo = j.nombre() + "  ·  " + j.personaje().pais();
        alinear(g, titulo, x, 26, Color.WHITE, derecha);

        double w = 230, bx = derecha ? x - w : x;                  // barra de poder
        g.setColor(new Color(255, 255, 255, 60));
        g.fill(new RoundRectangle2D.Double(bx, 36, w, 14, 8, 8));
        boolean listo = j.puedeArmar() || j.poderArmado();
        g.setColor(listo ? Estilo.ACENTO : Estilo.VERDE);
        double llena = j.poderArmado() ? 1 : j.carga();
        g.fill(new RoundRectangle2D.Double(derecha ? bx + w - w * llena : bx, 36, w * llena, 14, 8, 8));

        g.setFont(Estilo.fuente(Font.PLAIN, 14));
        alinear(g, "Poder: " + j.tipoPoder().etiqueta() + " · " + j.poderActivo(), x, 68, Estilo.SUAVE, derecha);
        if (partido.usaBalones()) {                                // balones restantes
            int n = partido.marcador().balones(j.lado());
            for (int i = 0; i < ReglaSupervivencia.BALONES_INICIALES; i++) {
                double px = derecha ? x - 10 - i * 22 : x + 10 + i * 22;
                g.setColor(i < n ? Color.WHITE : new Color(255, 255, 255, 50));
                g.fillOval((int) px - 8, 74, 16, 16);
            }
        }
    }

    private void dibujarAvisos(Graphics2D g) {
        double y = 130;
        g.setFont(Estilo.fuente(Font.BOLD, 30));
        for (Aviso a : avisos) {
            float alfa = (float) Math.min(1, a.restante / 0.6);
            FontMetrics fm = g.getFontMetrics();
            double w = fm.stringWidth(a.texto) + 40;
            g.setColor(new Color(0, 0, 0, (int) (150 * alfa)));
            g.fill(new RoundRectangle2D.Double(Campo.ANCHO / 2 - w / 2, y - 32, w, 46, 20, 20));
            g.setColor(new Color(1f, 0.79f, 0.24f, alfa));
            g.drawString(a.texto, (float) (Campo.ANCHO / 2 - w / 2 + 20), (float) y);
            y += 54;
        }
    }

    private void dibujarCuenta(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 90));
        g.fillRect(0, 92, (int) Campo.ANCHO, (int) Campo.ALTO - 92);
        String t = cuenta > 0.01 ? String.valueOf((int) Math.ceil(cuenta)) : "¡YA!";
        g.setFont(Estilo.fuente(Font.BOLD, 130));
        centrar(g, t, Campo.ANCHO / 2, 330, Estilo.ACENTO);
        g.setFont(Estilo.fuente(Font.PLAIN, 18));
        centrar(g, "P / Esc: pausa", Campo.ANCHO / 2, 380, Color.WHITE);
    }

    private void dibujarPausa(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 170));
        g.fillRect(0, 0, (int) Campo.ANCHO, (int) Campo.ALTO);
        g.setColor(Estilo.PANEL);
        g.fill(new RoundRectangle2D.Double(300, 130, 400, 398, 30, 30));
        g.setFont(Estilo.fuente(Font.BOLD, 42));
        centrar(g, "PAUSA", Campo.ANCHO / 2, 195, Color.WHITE);

        botonesPausa.clear();
        String[] textos = {"Continuar", "Controles", "Guardar partida", "Salir al menú"};
        Runnable[] acciones = {this::alternarPausa, this::mostrarControlesEnPausa,
                this::guardarPartida, () -> { detener(); nav.mostrarMenu(); }};
        for (int i = 0; i < textos.length; i++) {
            RoundRectangle2D forma = new RoundRectangle2D.Double(345, 220 + i * 68, 310, 52, 18, 18);
            botonesPausa.add(new BotonPausa(textos[i], forma, acciones[i]));
            g.setColor(Estilo.ACENTO);
            g.fill(forma);
            g.setFont(Estilo.fuente(Font.BOLD, 20));
            centrar(g, textos[i], Campo.ANCHO / 2, 258 + i * 68, Estilo.FONDO);
        }
    }

    private void mostrarControlesEnPausa() {
        JOptionPane.showMessageDialog(this, PanelControles.tabla(), "Controles", JOptionPane.PLAIN_MESSAGE);
        requestFocusInWindow();
    }

    // Guarda la partida activa desde el menú de pausa. 
    private void guardarPartida() {
        JFileChooser selector = new JFileChooser();
        selector.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Partida POOBSoccer (*." + PersistenciaPartida.EXTENSION + ")",
                PersistenciaPartida.EXTENSION));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        java.io.File archivo = selector.getSelectedFile();
        String nombre = archivo.getName();
        if (!nombre.toLowerCase().endsWith("." + PersistenciaPartida.EXTENSION))
            archivo = new java.io.File(archivo.getParentFile(), nombre + "." + PersistenciaPartida.EXTENSION);
        try {
            PersistenciaPartida.guardar(archivo, partido);
            JOptionPane.showMessageDialog(this, "Partida guardada.", "Guardado", JOptionPane.INFORMATION_MESSAGE);
        } catch (java.io.IOException | POOBSoccerException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo guardar", JOptionPane.ERROR_MESSAGE);
        }
        requestFocusInWindow();
    }

    private static void centrar(Graphics2D g, String t, double cx, double y, Color c) {
        g.setColor(c);
        g.drawString(t, (float) (cx - g.getFontMetrics().stringWidth(t) / 2.0), (float) y);
    }
    private static void alinear(Graphics2D g, String t, double x, double y, Color c, boolean derecha) {
        g.setColor(c);
        g.drawString(t, (float) (derecha ? x - g.getFontMetrics().stringWidth(t) : x), (float) y);
    }
}
