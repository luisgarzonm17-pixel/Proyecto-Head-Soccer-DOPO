package presentation;

import javax.swing.*;
import java.awt.*;

// Menú principal. 
public class PanelMenu extends JPanel {
    public PanelMenu(Navegador nav) {
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(Box.createVerticalGlue());
        add(titulo());
        add(Box.createVerticalStrut(40));
        add(Estilo.boton("Jugar", nav::mostrarConfiguracion));
        add(Box.createVerticalStrut(14));
        add(Estilo.boton("Controles", nav::mostrarControles));
        add(Box.createVerticalStrut(14));
        add(Estilo.boton("Abrir partida", nav::abrirPartida));
        add(Box.createVerticalStrut(14));
        add(Estilo.boton("Salir", () -> System.exit(0)));
        add(Box.createVerticalGlue());
    }

    private JComponent titulo() {
        JComponent t = new JComponent() {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Estilo.suavizar(g);
                g.setFont(Estilo.fuente(Font.BOLD, 76));
                String a = "POOB", b = "SOCCER";
                FontMetrics fm = g.getFontMetrics();
                g.setColor(new Color(0, 0, 0, 120));
                g.drawString(a + " " + b, (getWidth() - fm.stringWidth(a + " " + b)) / 2 + 4, 84);
                int x = (getWidth() - fm.stringWidth(a + " " + b)) / 2;
                g.setColor(Estilo.ACENTO);
                g.drawString(a, x, 80);
                g.setColor(Color.WHITE);
                g.drawString(" " + b, x + fm.stringWidth(a), 80);
                g.setFont(Estilo.fuente(Font.PLAIN, 18));
                g.setColor(Estilo.SUAVE);
                String sub = "Fútbol arcade 2D · Escuela Colombiana de Ingeniería";
                g.drawString(sub, (getWidth() - g.getFontMetrics().stringWidth(sub)) / 2, 115);
                g.dispose();
            }
        };
        t.setPreferredSize(new Dimension(800, 130));
        t.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        t.setAlignmentX(Component.CENTER_ALIGNMENT);
        return t;
    }

    @Override protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondo(g, getWidth(), getHeight());
        g.dispose();
    }
}
