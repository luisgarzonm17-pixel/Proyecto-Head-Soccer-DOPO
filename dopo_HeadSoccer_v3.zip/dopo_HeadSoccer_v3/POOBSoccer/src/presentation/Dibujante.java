package presentation;

import domain.*;

import java.awt.*;
import java.awt.geom.*;
import java.util.Random;

// Dibuja la cancha, los personajes y el balón. No contiene lógica de juego. 
final class Dibujante {
    private static final int HINCHAS = 520;
    private static final double[] HX = new double[HINCHAS], HY = new double[HINCHAS];
    private static final Color[] HC = new Color[HINCHAS];
    static {
        Random r = new Random(7);
        Color[] paleta = {new Color(0xE74C3C), new Color(0xF1C40F), new Color(0x3498DB), new Color(0xECF0F1),
                          new Color(0x2ECC71), new Color(0x9B59B6)};
        for (int i = 0; i < HINCHAS; i++) {
            HX[i] = r.nextDouble() * Campo.ANCHO;
            HY[i] = 130 + r.nextDouble() * 300;
            HC[i] = paleta[r.nextInt(paleta.length)];
        }
    }

    private Dibujante() {}

    static void cancha(Graphics2D g) {
        g.setPaint(new GradientPaint(0, 0, new Color(0x0B1E3A), 0, 440, new Color(0x2B4A78)));
        g.fillRect(0, 0, (int) Campo.ANCHO, (int) Campo.ALTO);
        for (int i = 0; i < HINCHAS; i++) {                       // gradas
            g.setColor(HC[i]);
            g.fill(new Ellipse2D.Double(HX[i], HY[i], 9, 11));
        }
        g.setColor(new Color(0x101A2A));                          // vallas publicitarias
        g.fillRect(0, 440, (int) Campo.ANCHO, (int) (Campo.SUELO - 440));
        g.setFont(Estilo.fuente(Font.BOLD, 22));
        for (int x = 0; x < Campo.ANCHO; x += 250) {
            g.setColor(new Color(x / 250 % 2 == 0 ? 0xFFC93C : 0x2FA84F));
            g.drawString("POOBSoccer", x + 40, 490);
        }
        for (int i = 0; i < 10; i++) {                            // césped a franjas
            g.setColor(i % 2 == 0 ? new Color(0x2E8B3E) : new Color(0x34A047));
            g.fillRect(i * 100, (int) Campo.SUELO, 100, (int) (Campo.ALTO - Campo.SUELO));
        }
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(4));
        g.drawLine(0, (int) Campo.SUELO, (int) Campo.ANCHO, (int) Campo.SUELO);
        g.setStroke(new BasicStroke(2));
        g.setColor(new Color(255, 255, 255, 120));
        g.drawLine((int) Campo.ANCHO / 2, (int) Campo.SUELO, (int) Campo.ANCHO / 2, (int) Campo.ALTO);
    }

    static void arco(Graphics2D g, Porteria p) {
        Hitbox z = p.zona();
        g.setColor(new Color(255, 255, 255, 40));
        g.fill(new Rectangle2D.Double(z.x(), z.y(), z.ancho(), z.alto()));
        g.setColor(new Color(255, 255, 255, 110));
        g.setStroke(new BasicStroke(1));
        for (double x = z.x(); x <= z.x() + z.ancho(); x += 15) g.draw(new Line2D.Double(x, z.y(), x, z.y() + z.alto()));
        for (double y = z.y(); y <= z.y() + z.alto(); y += 15) g.draw(new Line2D.Double(z.x(), y, z.x() + z.ancho(), y));
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(7, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        double poste = p.lado() == Lado.IZQUIERDO ? z.x() + z.ancho() : z.x();
        g.draw(new Line2D.Double(z.x(), z.y(), z.x() + z.ancho(), z.y()));         // travesaño
        g.draw(new Line2D.Double(poste, z.y(), poste, z.y() + z.alto()));            // poste
    }

    static void balon(Graphics2D g, Balon b) {
        double x = b.pos().x(), y = b.pos().y(), r = b.radio();
        g.setColor(new Color(0, 0, 0, 60));
        g.fill(new Ellipse2D.Double(x - r * 0.9, Campo.SUELO - 4, r * 1.8, 8));
        g.setColor(Color.WHITE);
        g.fill(new Ellipse2D.Double(x - r, y - r, 2 * r, 2 * r));
        AffineTransform viejo = g.getTransform();
        g.rotate(x / r / 1.5, x, y);
        Path2D pent = new Path2D.Double();
        for (int i = 0; i < 5; i++) {
            double a = -Math.PI / 2 + i * 2 * Math.PI / 5;
            double px = x + Math.cos(a) * r * 0.5, py = y + Math.sin(a) * r * 0.5;
            if (i == 0) pent.moveTo(px, py); else pent.lineTo(px, py);
        }
        pent.closePath();
        g.setColor(new Color(0x222222));
        g.fill(pent);
        g.setStroke(new BasicStroke(1.5f));
        for (int i = 0; i < 5; i++) {
            double a = -Math.PI / 2 + i * 2 * Math.PI / 5;
            g.draw(new Line2D.Double(x + Math.cos(a) * r * 0.5, y + Math.sin(a) * r * 0.5,
                                     x + Math.cos(a) * r * 0.98, y + Math.sin(a) * r * 0.98));
        }
        g.setTransform(viejo);
        g.setStroke(new BasicStroke(2));
        g.setColor(new Color(0x333333));
        g.draw(new Ellipse2D.Double(x - r, y - r, 2 * r, 2 * r));
    }

    // Cabeza de un personaje (se reutiliza en la pantalla de selección y de resultados). 
    static void cabeza(Graphics2D g, double cx, double cy, double r, String pais, int dir) {
        Color[] c = Paises.colores(pais);
        Shape cab = new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r);
        g.setColor(Paises.piel(pais));
        g.fill(cab);
        Shape viejo = g.getClip();
        g.clip(cab);
        g.setColor(c[0]);
        g.fill(new Rectangle2D.Double(cx - r, cy - r, 2 * r, r * 0.62));
        g.setColor(c[1]);
        g.fill(new Rectangle2D.Double(cx - r, cy - r * 0.38, 2 * r, r * 0.14));
        g.setClip(viejo);
        g.setColor(c[0].darker());
        g.fill(new RoundRectangle2D.Double(dir > 0 ? cx + r * 0.2 : cx - r * 1.15, cy - r * 0.40, r * 0.95, r * 0.18, 6, 6));
        for (double off : new double[]{0.12, 0.58}) {             // ojos
            double ex = cx + dir * r * off;
            g.setColor(Color.WHITE);
            g.fill(new Ellipse2D.Double(ex - r * 0.15, cy - r * 0.02, r * 0.3, r * 0.4));
            g.setColor(Color.BLACK);
            g.fill(new Ellipse2D.Double(ex - r * 0.07 + dir * r * 0.05, cy + r * 0.08, r * 0.14, r * 0.2));
        }
        g.setStroke(new BasicStroke((float) Math.max(1.5, r * 0.05)));
        g.setColor(new Color(0x5A2A1A));
        g.draw(new Arc2D.Double(cx + dir * r * 0.15 - r * 0.2, cy + r * 0.38, r * 0.5, r * 0.25, 200, 140, Arc2D.OPEN));
        g.setColor(new Color(0x1A1A1A));
        g.setStroke(new BasicStroke((float) Math.max(2, r * 0.07)));
        g.draw(cab);
    }

    static void personaje(Graphics2D g, Jugador j) {
        Personaje p = j.personaje();
        double cx = p.pos().x(), cy = p.pos().y(), r = p.radio();
        int dir = j.lado().direccionAtaque();
        long t = System.currentTimeMillis();

        g.setColor(new Color(0, 0, 0, 70));
        g.fill(new Ellipse2D.Double(cx - r * 0.9, Campo.SUELO - 4, r * 1.8, 8));
        if (j.poderArmado()) {                                     // aura del poder armado
            float a = 0.5f + 0.4f * (float) Math.sin(t / 120.0);
            g.setColor(new Color(1f, 0.85f, 0.2f, a));
            g.setStroke(new BasicStroke(6));
            g.draw(new Ellipse2D.Double(cx - r - 6, cy - r - 6, 2 * r + 12, 2 * r + 12));
        }
        cabeza(g, cx, cy, r, p.pais(), dir);
        if (p.pateando()) {                                        // bota
            g.setColor(Paises.colores(p.pais())[1].equals(Color.WHITE) ? Paises.colores(p.pais())[0] : Paises.colores(p.pais())[1]);
            g.fill(new Ellipse2D.Double(cx + dir * r * 0.95 - r * 0.45, cy + r * 0.55, r * 0.9, r * 0.5));
            g.setColor(Color.BLACK);
            g.setStroke(new BasicStroke(2));
            g.draw(new Ellipse2D.Double(cx + dir * r * 0.95 - r * 0.45, cy + r * 0.55, r * 0.9, r * 0.5));
        }
        if (p.tiene(TipoEfecto.CONGELADO)) {
            g.setColor(new Color(150, 220, 255, 150));
            g.fill(new RoundRectangle2D.Double(cx - r - 5, cy - r - 5, 2 * r + 10, 2 * r + 10, 14, 14));
            g.setColor(new Color(255, 255, 255, 220));
            g.setStroke(new BasicStroke(3));
            g.draw(new RoundRectangle2D.Double(cx - r - 5, cy - r - 5, 2 * r + 10, 2 * r + 10, 14, 14));
        }
        if (p.tiene(TipoEfecto.ATURDIDO)) {
            for (int i = 0; i < 3; i++) {
                double a = t / 250.0 + i * 2 * Math.PI / 3;
                estrella(g, cx + Math.cos(a) * r * 0.8, cy - r - 10 + Math.sin(a) * 6, 8);
            }
        }
        g.setFont(Estilo.fuente(Font.BOLD, 28));
        g.setColor(Color.WHITE);
        if (p.tiene(TipoEfecto.CONFUNDIDO)) g.drawString("?", (float) cx - 8, (float) (cy - r - 8));
        if (p.tiene(TipoEfecto.LENTO)) g.drawString("z z", (float) cx - 16, (float) (cy - r - 8));
        g.setFont(Estilo.fuente(Font.BOLD, 14));
        FontMetrics fm = g.getFontMetrics();
        String etiqueta = j.lado() == Lado.IZQUIERDO ? "J1" : "J2";
        g.setColor(new Color(0, 0, 0, 140));
        g.fill(new RoundRectangle2D.Double(cx - 14, cy + r + 6 - 15, 28, 18, 8, 8));
        g.setColor(Color.WHITE);
        g.drawString(etiqueta, (float) (cx - fm.stringWidth(etiqueta) / 2.0), (float) (cy + r + 6 - 2));
    }

    private static void estrella(Graphics2D g, double x, double y, double r) {
        Path2D s = new Path2D.Double();
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 == 0 ? r : r * 0.45;
            double px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
            if (i == 0) s.moveTo(px, py); else s.lineTo(px, py);
        }
        s.closePath();
        g.setColor(new Color(0xFFD400));
        g.fill(s);
    }
}
