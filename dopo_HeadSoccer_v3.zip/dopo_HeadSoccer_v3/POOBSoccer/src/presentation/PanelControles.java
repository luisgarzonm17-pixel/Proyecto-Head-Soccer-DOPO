package presentation;

import javax.swing.*;
import java.awt.*;

// Pantalla con la tabla de controles de los dos jugadores. 
public class PanelControles extends JPanel {
    static final String[][] FILAS = {
        {"Acción", "Jugador 1", "Jugador 2"},
        {"Mover a la izquierda", "A", "←"},
        {"Mover a la derecha", "D", "→"},
        {"Saltar", "W", "↑"},
        {"Patear", "S", "↓"},
        {"Usar poder", "Q", "Ctrl derecho"},
        {"Pausar", "P o Esc", "P o Esc"},
    };

    public PanelControles(Navegador nav) {
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(Box.createVerticalGlue());
        add(centrado(Estilo.etiqueta("Controles", 40, Font.BOLD, Estilo.ACENTO)));
        add(Box.createVerticalStrut(20));
        add(centrado(tabla()));
        add(Box.createVerticalStrut(14));
        add(centrado(Estilo.etiqueta("Contra la máquina puedes usar cualquiera de los dos juegos de teclas.", 15, Font.PLAIN, Estilo.SUAVE)));
        add(Box.createVerticalStrut(26));
        add(Estilo.boton("Volver", nav::mostrarMenu));
        add(Box.createVerticalGlue());
    }

    static JComponent tabla() {
        JPanel t = new JPanel(new GridLayout(FILAS.length, 3, 2, 2));
        t.setBackground(Estilo.SUAVE);
        t.setMaximumSize(new Dimension(620, 40 * FILAS.length));
        for (int i = 0; i < FILAS.length; i++)
            for (String celda : FILAS[i]) {
                JLabel l = Estilo.etiqueta(celda, 18, i == 0 ? Font.BOLD : Font.PLAIN, i == 0 ? Estilo.FONDO : Color.WHITE);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                l.setOpaque(true);
                l.setBackground(i == 0 ? Estilo.ACENTO : Estilo.PANEL);
                l.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
                t.add(l);
            }
        return t;
    }

    private static JComponent centrado(JComponent c) { c.setAlignmentX(Component.CENTER_ALIGNMENT); return c; }

    @Override protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondo(g, getWidth(), getHeight());
        g.dispose();
    }
}
