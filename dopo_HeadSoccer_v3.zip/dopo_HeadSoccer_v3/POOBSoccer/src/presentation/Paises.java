package presentation;

import java.awt.Color;

// Colores de cada país: son un asunto de presentación, por eso no están en el dominio. 
final class Paises {
    private Paises() {}

    static Color[] colores(String pais) {
        return switch (pais) {
            case "Canadá"   -> new Color[]{new Color(0xD52B1E), Color.WHITE};
            case "Colombia" -> new Color[]{new Color(0xFCD116), new Color(0x003893)};
            case "Brasil"   -> new Color[]{new Color(0x009C3B), new Color(0xFFDF00)};
            case "México"   -> new Color[]{new Color(0x006847), new Color(0xCE1126)};
            default         -> new Color[]{Color.GRAY, Color.WHITE};
        };
    }

    static Color piel(String pais) {
        return switch (pais) {
            case "Canadá"   -> new Color(0xF2C9A0);
            case "Colombia" -> new Color(0xD9A06B);
            case "Brasil"   -> new Color(0xA8693D);
            case "México"   -> new Color(0xC98B58);
            default         -> new Color(0xE0B890);
        };
    }
}
