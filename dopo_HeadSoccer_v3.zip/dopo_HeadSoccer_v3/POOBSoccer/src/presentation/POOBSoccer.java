package presentation;

import javax.swing.*;

// Punto de entrada del juego. 
public class POOBSoccer {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
            catch (Exception ignorada) {
                // Se conserva el aspecto visual predeterminado si no se puede cargar el seleccionado.
            }
            new VentanaPrincipal().setVisible(true);
        });
    }
}
