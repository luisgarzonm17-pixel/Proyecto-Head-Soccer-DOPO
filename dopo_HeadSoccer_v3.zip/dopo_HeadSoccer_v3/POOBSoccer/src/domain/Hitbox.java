package domain;

// Rectángulo alineado a los ejes, usado como zona de las porterías. 
public record Hitbox(double x, double y, double ancho, double alto) {

    public boolean contieneCompleto(Vector centro, double radio) {
        return centro.x() - radio >= x && centro.x() + radio <= x + ancho
            && centro.y() - radio >= y && centro.y() + radio <= y + alto;
    }
}
