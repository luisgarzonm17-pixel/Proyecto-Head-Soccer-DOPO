package domain;

// Lado de la cancha que defiende un jugador. 
public enum Lado {
    IZQUIERDO(1), DERECHO(-1);

    private final int direccionAtaque;
    Lado(int d) { direccionAtaque = d; }

    // +1 si ataca hacia la derecha, -1 si ataca hacia la izquierda. 
    public int direccionAtaque() { return direccionAtaque; }
    public Lado opuesto() { return this == IZQUIERDO ? DERECHO : IZQUIERDO; }
}
