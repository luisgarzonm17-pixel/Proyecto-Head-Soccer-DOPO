package domain;

// Error de reglas / configuración del dominio. 
public class POOBSoccerException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public static final String SUPERVIVENCIA_SOLO_PVSM = "La supervivencia solo está disponible en Jugador vs Máquina.";
    public static final String META_INVALIDA = "El partido por goles se juega a 3, 5 o 7 goles.";
    public static final String DATOS_INCOMPLETOS = "Faltan datos para crear el partido.";
    public static final String ESTADISTICA_INVALIDA = "Las estadísticas deben estar entre 1 y 5.";
    public static final String ESTADO_INVALIDO = "Operación no permitida en el estado actual del partido.";

    public POOBSoccerException(String mensaje) { super(mensaje); }
}
