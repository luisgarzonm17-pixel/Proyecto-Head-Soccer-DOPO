package domain;

// Poder especial: al dispararse afecta al oponente (polimorfismo: cada subclase define su efecto). 
public abstract class Poder {
    private final TipoPoder tipo;
    private final TipoEfecto efecto;
    private final double duracion;

    protected Poder(TipoPoder tipo, TipoEfecto efecto, double duracion) {
        this.tipo = tipo; this.efecto = efecto; this.duracion = duracion;
    }
    public TipoPoder tipo() { return tipo; }
    public String nombre() { return tipo.etiqueta(); }
    public double duracion() { return duracion; }

    // Aplica el poder sobre el rival. 
    public void aplicar(Personaje rival) { rival.aplicarEfecto(efecto, duracion); }
}
