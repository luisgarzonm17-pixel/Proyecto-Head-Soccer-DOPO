package domain;

// Quién controla a cada jugador. 
public enum Modalidad {
    PVSP("Jugador vs Jugador", 2),
    PVSM("Jugador vs Máquina", 1);

    private final String etiqueta;
    private final int humanos;
    Modalidad(String e, int h) { etiqueta = e; humanos = h; }

    public String etiqueta() { return etiqueta; }
    public int cantidadHumanos() { return humanos; }
    @Override public String toString() { return etiqueta; }
}
