package domain;

import java.util.List;

// Personajes disponibles. Para agregar un país basta con añadir una ficha. 
public final class CatalogoPersonajes {
    private static final List<FichaPersonaje> TODOS = List.of(
        new FichaPersonaje("Maple",    "Canadá",   2, 3, 5, TipoPoder.CONGELACION),
        new FichaPersonaje("Cafetero", "Colombia", 4, 4, 2, TipoPoder.REDUCCION),
        new FichaPersonaje("Samba",    "Brasil",   5, 3, 3, TipoPoder.CONFUSION),
        new FichaPersonaje("Charro",   "México",   3, 5, 3, TipoPoder.LENTITUD));

    private CatalogoPersonajes() {}
    public static List<FichaPersonaje> todos() { return TODOS; }
}
