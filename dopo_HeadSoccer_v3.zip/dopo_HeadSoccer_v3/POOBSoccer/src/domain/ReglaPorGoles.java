package domain;

// Gana el primero que llegue a la meta (3, 5 o 7), sin límite de tiempo. 
public class ReglaPorGoles extends ReglaPartido {
    private final int meta;

    public ReglaPorGoles(int meta) {
        if (meta != 3 && meta != 5 && meta != 7) throw new POOBSoccerException(POOBSoccerException.META_INVALIDA);
        this.meta = meta;
    }
    public int meta() { return meta; }
    @Override public void iniciar(Marcador m) {
        if (m == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
    }
    @Override public void alAvanzar(double dt, Marcador m) {
        if (dt < 0 || m == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
    }
    @Override public void alGol(Lado anotador, Marcador m) {
        if (anotador == null || m == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
    }

    @Override public boolean terminado(Marcador m) {
        return m.goles(Lado.IZQUIERDO) >= meta || m.goles(Lado.DERECHO) >= meta;
    }
    @Override public Lado ganador(Marcador m) { return terminado(m) ? m.lider() : null; }
    @Override public String descripcion() { return "Por goles: a " + meta; }
}
