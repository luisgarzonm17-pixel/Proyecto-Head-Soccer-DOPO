package domain;

// Lo que un jugador (humano o máquina) quiere hacer en un instante. La presentación la construye desde el teclado. 
public record Intencion(boolean izquierda, boolean derecha, boolean saltar, boolean patear, boolean poder) {
    public static final Intencion NINGUNA = new Intencion(false, false, false, false, false);

    public Intencion combinar(Intencion o) {
        return new Intencion(izquierda || o.izquierda, derecha || o.derecha, saltar || o.saltar,
                             patear || o.patear, poder || o.poder);
    }
}
