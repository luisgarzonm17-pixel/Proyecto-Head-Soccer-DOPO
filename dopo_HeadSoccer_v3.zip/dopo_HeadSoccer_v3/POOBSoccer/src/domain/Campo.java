package domain;

import java.util.EnumMap;
import java.util.Map;

// Cancha: dimensiones, porterías y rebotes del balón (suelo, techo, paredes y travesaños). 
public final class Campo {
    public static final double ANCHO = 1000, ALTO = 600, SUELO = 520, ANCHO_ARCO = 90, ALTO_ARCO = 180;
    private static final double REST_SUELO = 0.72, REST_PARED = 0.80, REST_TRAVESANO = 0.60, ROZAMIENTO = 0.9;

    private final Map<Lado, Porteria> porterias = new EnumMap<>(Lado.class);

    public Campo() { for (Lado l : Lado.values()) porterias.put(l, new Porteria(l)); }

    public Porteria porteria(Lado l) { return porterias.get(l); }
    public double xInicial(Lado l) { return l == Lado.IZQUIERDO ? ANCHO * 0.25 : ANCHO * 0.75; }

    public Lado arcoConGol(Balon b) {
        for (Porteria p : porterias.values()) if (p.anotado(b)) return p.lado();
        return null;
    }

    public void contenerPersonaje(Personaje p) {
        double r = p.radio();
        double x = Math.max(r, Math.min(ANCHO - r, p.pos().x()));
        double y = p.pos().y(), vy = p.vel().y();
        if (y + r >= SUELO) { y = SUELO - r; if (vy > 0) vy = 0; }
        if (y - r < 0)      { y = r;         if (vy < 0) vy = 0; }
        p.fijarPos(new Vector(x, y));
        p.fijarVel(new Vector(p.vel().x(), vy));
    }

    public void contenerBalon(Balon b, double dt) {
        double r = b.radio(), x = b.pos().x(), y = b.pos().y(), vx = b.vel().x(), vy = b.vel().y();

        for (Porteria g : porterias.values()) {            // travesaños
            double top = g.alturaTravesano();
            if (vy >= 0 && g.estaSobreTravesano(b) && y + r > top && y + r < top + 25 && y - r < top) {
                y = top - r;
                vy = -vy * REST_TRAVESANO;
                if (Math.abs(vy) < 40) {                    // evita que el balón quede quieto sobre el arco
                    vy = 0;
                    if (Math.abs(vx) < 30) vx = (g.lado() == Lado.IZQUIERDO ? 1 : -1) * 80;
                }
            }
        }
        if (y + r > SUELO) {                                // suelo
            y = SUELO - r;
            if (vy > 0) { vy = -vy * REST_SUELO; if (Math.abs(vy) < 70) vy = 0; }
            vx *= Math.max(0, 1 - ROZAMIENTO * dt);
        }
        if (y - r < 0 && vy < 0) { y = r; vy = -vy * REST_PARED; }   // techo
        if (x - r < 0)     { x = r;         vx =  Math.abs(vx) * REST_PARED; }
        if (x + r > ANCHO) { x = ANCHO - r; vx = -Math.abs(vx) * REST_PARED; }
        b.fijarPos(new Vector(x, y));
        b.fijarVel(new Vector(vx, vy));
    }
}
