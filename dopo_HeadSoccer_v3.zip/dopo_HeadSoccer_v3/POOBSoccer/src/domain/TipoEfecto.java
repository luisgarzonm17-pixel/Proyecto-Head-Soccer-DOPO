package domain;

// Estados temporales que puede sufrir un personaje. 
public enum TipoEfecto {
    ATURDIDO("Aturdido"), CONGELADO("Congelado"), REDUCIDO("Reducido"),
    CONFUNDIDO("Confundido"), LENTO("Lento");

    private final String etiqueta;
    TipoEfecto(String e) { etiqueta = e; }
    public String etiqueta() { return etiqueta; }
    // Los efectos que impiden mover, saltar y patear. 
    public boolean inmoviliza() { return this == ATURDIDO || this == CONGELADO; }
}
