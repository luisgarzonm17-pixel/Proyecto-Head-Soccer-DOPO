package domain;

// Datos fijos de un personaje: nombre, país, estadísticas (1 a 5) y poder único. 
public record FichaPersonaje(String nombre, String pais, int velocidad, int salto, int fuerza, TipoPoder poder) {
    public FichaPersonaje {
        if (nombre == null || pais == null || poder == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        for (int s : new int[]{velocidad, salto, fuerza})
            if (s < 1 || s > 5) throw new POOBSoccerException(POOBSoccerException.ESTADISTICA_INVALIDA);
    }
}
