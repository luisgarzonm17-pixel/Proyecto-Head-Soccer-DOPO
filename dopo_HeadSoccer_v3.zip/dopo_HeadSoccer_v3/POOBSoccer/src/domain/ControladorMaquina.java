package domain;

import java.util.Random;

// Jugador controlado por la máquina: persigue el balón, patea, salta y usa el poder. 
public class ControladorMaquina implements Controlador {
    private final Dificultad dificultad;
    private final Random azar;
    private double espera;
    private double error;
    private Intencion actual = Intencion.NINGUNA;

    public ControladorMaquina(Dificultad dificultad, long semilla) {
        this.dificultad = dificultad;
        this.azar = new Random(semilla);
    }

    @Override public Intencion decidir(Partido partido, Jugador yo, double dt) {
        espera -= dt;
        if (espera > 0) return actual;
        espera = dificultad.reaccion();

        Personaje yoP = yo.personaje();
        Balon b = partido.balon();
        int dir = yo.lado().direccionAtaque();
        double dx = b.pos().x() - yoP.pos().x();
        boolean balonDetras = dx * dir < -yoP.radio();
        double contacto = yoP.radio() + b.radio();

        error = (azar.nextDouble() * 2 - 1) * dificultad.error();
        // Se coloca del lado de su propio arco respecto al balón, para empujarlo hacia el rival.
        double objetivo = b.pos().x() - dir * (contacto + 12) + error;
        boolean der = false, izq = false;
        if (Math.abs(objetivo - yoP.pos().x()) > 10) { der = objetivo > yoP.pos().x(); izq = !der; }

        double dist = b.pos().menos(yoP.pos()).longitud();
        boolean patear = !balonDetras && dist < contacto + 32;
        boolean saltar = yoP.enSuelo() && (
            (!balonDetras && b.pos().y() < yoP.pos().y() - 50 && Math.abs(dx) < 130)
            || (balonDetras && Math.abs(dx) < contacto + 70));   // salta sobre el balón para regresar
        boolean poder = yo.puedeArmar() && Math.abs(dx) < 350;

        actual = new Intencion(izq, der, saltar, patear, poder);
        return actual;
    }
}
