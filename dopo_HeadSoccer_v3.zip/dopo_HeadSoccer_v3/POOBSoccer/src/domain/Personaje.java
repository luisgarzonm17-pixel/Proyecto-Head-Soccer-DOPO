package domain;

import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.Collections;

// Personaje en la cancha: se mueve, salta, patea y puede sufrir efectos temporales. 
public class Personaje extends Cuerpo {
    public static final double RADIO_BASE = 38;
    public static final double SEG_ATURDIMIENTO = 3.0;
    private static final double GRAVEDAD = 2200, DURACION_PATADA = 0.25, ENFRIAMIENTO_PATADA = 0.55, INMUNIDAD = 1.5;

    private final FichaPersonaje ficha;
    private final Map<TipoEfecto, Double> efectos = new EnumMap<>(TipoEfecto.class);
    private double inmunidad, patadaRestante, enfriamiento;
    private boolean patadaUsadaEnBalon, patadaUsadaEnRival;

    public Personaje(FichaPersonaje ficha) { this.ficha = ficha; }

    public FichaPersonaje ficha() { return ficha; }
    public String nombre() { return ficha.nombre(); }
    public String pais() { return ficha.pais(); }

    @Override public double radio() { return RADIO_BASE * (tiene(TipoEfecto.REDUCIDO) ? 0.5 : 1.0); }

    public boolean tiene(TipoEfecto e) { return efectos.containsKey(e); }
    public Set<TipoEfecto> efectosActivos() { return Collections.unmodifiableSet(efectos.keySet()); }
    public boolean inmovilizado() { return efectos.keySet().stream().anyMatch(TipoEfecto::inmoviliza); }
    public boolean enSuelo() { return pos().y() + radio() >= Campo.SUELO - 0.5; }
    public boolean pateando() { return patadaRestante > 0; }
    public double fuerzaPatada() { return 450 + 130 * ficha.fuerza(); }

    private double velocidadHorizontal() {
        return (170 + 50 * ficha.velocidad()) * (tiene(TipoEfecto.LENTO) ? 0.4 : 1.0);
    }
    private double velocidadSalto() {
        return (640 + 70 * ficha.salto()) * (tiene(TipoEfecto.REDUCIDO) ? 0.8 : 1.0);
    }

    // Aplica un efecto. Los que inmovilizan no se acumulan y dan inmunidad corta al terminar. 
    public void aplicarEfecto(TipoEfecto e, double segundos) {
        if (e.inmoviliza() && (inmunidad > 0 || inmovilizado())) return;
        efectos.merge(e, segundos, Math::max);
        if (e.inmoviliza()) patadaRestante = 0;
    }

    // Traduce la intención en velocidad / salto / patada, respetando los efectos activos. 
    public void actuar(Intencion in, double dt) {
        double vx = 0;
        if (!inmovilizado()) {
            int dir = (in.derecha() ? 1 : 0) - (in.izquierda() ? 1 : 0);
            if (tiene(TipoEfecto.CONFUNDIDO)) dir = -dir;
            vx = dir * velocidadHorizontal();
            if (in.saltar() && enSuelo()) fijarVel(new Vector(vel().x(), -velocidadSalto()));
            if (in.patear() && enfriamiento <= 0) {
                patadaRestante = DURACION_PATADA; enfriamiento = ENFRIAMIENTO_PATADA;
                patadaUsadaEnBalon = false; patadaUsadaEnRival = false;
            }
        }
        fijarVel(new Vector(vx, vel().y()));
    }

    // Avanza el tiempo: efectos, patada, gravedad y posición. 
    public void avanzar(double dt) {
        boolean estabaInmovilizado = inmovilizado();
        efectos.replaceAll((e, t) -> t - dt);
        efectos.values().removeIf(t -> t <= 0);
        if (estabaInmovilizado && !inmovilizado()) inmunidad = INMUNIDAD;
        inmunidad = Math.max(0, inmunidad - dt);
        patadaRestante = Math.max(0, patadaRestante - dt);
        enfriamiento = Math.max(0, enfriamiento - dt);
        fijarVel(vel().mas(new Vector(0, GRAVEDAD * dt)));
        fijarPos(pos().mas(vel().por(dt)));
    }

    boolean consumirPatadaEnBalon() { if (!pateando() || patadaUsadaEnBalon) return false; return patadaUsadaEnBalon = true; }
    boolean consumirPatadaEnRival() { if (!pateando() || patadaUsadaEnRival) return false; return patadaUsadaEnRival = true; }

    // Vuelve a la posición inicial y limpia efectos (después de un gol). 
    public void reiniciar(double x) {
        efectos.clear(); inmunidad = 0; patadaRestante = 0; enfriamiento = 0;
        fijarVel(Vector.CERO);
        fijarPos(new Vector(x, Campo.SUELO - radio()));
    }
}
