package domain;

// Un participante: personaje + barra de poder + quién lo controla. 
public class Jugador {
    public static final double SEGUNDOS_CARGA = 12;

    private final String nombre;
    private final Lado lado;
    private final Personaje personaje;
    private final Controlador controlador;
    private double carga;            // 0..1
    private boolean poderArmado;

    public Jugador(String nombre, Lado lado, FichaPersonaje ficha, Controlador controlador) {
        this.nombre = nombre; this.lado = lado; this.controlador = controlador;
        this.personaje = new Personaje(ficha);
    }

    public String nombre() { return nombre; }
    public Lado lado() { return lado; }
    public Personaje personaje() { return personaje; }
    public Controlador controlador() { return controlador; }
    public double carga() { return carga; }
    public boolean poderArmado() { return poderArmado; }
    public boolean puedeArmar() { return carga >= 1.0 && !poderArmado; }
    public TipoPoder tipoPoder() { return personaje.ficha().poder(); }

    // Texto del poder activo para el HUD. 
    public String poderActivo() {
        if (poderArmado) return tipoPoder().etiqueta() + " (armado)";
        return puedeArmar() ? "¡Listo!" : "—";
    }

    void cargar(double dt) { if (!poderArmado) carga = Math.min(1.0, carga + dt / SEGUNDOS_CARGA); }

    // El poder solo se puede usar con la barra llena. 
    void armar() { if (puedeArmar()) { poderArmado = true; carga = 0; } }
    // Restaura la carga y el estado armado al abrir una partida. 
    void restaurarPoder(double carga, boolean armado) {
        if (carga < 0 || carga > 1) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        this.carga = carga;
        this.poderArmado = armado;
    }

    // Se activa al golpear el balón y afecta al oponente. 
    Poder dispararPoder(Personaje rival) {
        poderArmado = false;
        Poder p = tipoPoder().crear();
        p.aplicar(rival);
        return p;
    }
}
