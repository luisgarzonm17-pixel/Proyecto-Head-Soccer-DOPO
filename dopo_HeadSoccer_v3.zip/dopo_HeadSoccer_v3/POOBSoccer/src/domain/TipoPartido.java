package domain;

public enum TipoPartido {
    TIEMPO("Por tiempo (60 s)"),
    GOLES("Por goles"),
    SUPERVIVENCIA("Supervivencia");

    private final String etiqueta;
    TipoPartido(String e) { etiqueta = e; }
    public String etiqueta() { return etiqueta; }
    @Override public String toString() { return etiqueta; }
}
