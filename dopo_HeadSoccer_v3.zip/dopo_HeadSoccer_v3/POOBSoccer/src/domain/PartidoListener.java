package domain;

// Observador de eventos del partido (la presentación se suscribe para mostrar avisos). 
public interface PartidoListener {
    // Recibe la notificación de un gol. 
    void alGol(Lado anotador);
    // Recibe la notificación del uso de un poder. 
    void alUsarPoder(Jugador jugador, Poder poder);
    // Recibe la notificación del final del partido. 
    void alTerminar(Lado ganador);
    // Recibe cambios de estado del partido. 
    void alCambiarEstado(EstadoPartido estado);
}
