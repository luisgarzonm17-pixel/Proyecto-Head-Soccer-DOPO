package domain;

// Vector 2D inmutable. El eje Y crece hacia abajo (como en pantalla). 
public record Vector(double x, double y) {
    public static final Vector CERO = new Vector(0, 0);

    public Vector mas(Vector o)   { return new Vector(x + o.x, y + o.y); }
    public Vector menos(Vector o) { return new Vector(x - o.x, y - o.y); }
    public Vector por(double k)   { return new Vector(x * k, y * k); }
    public double punto(Vector o) { return x * o.x + y * o.y; }
    public double longitud()      { return Math.hypot(x, y); }

    public Vector normalizado() {
        double l = longitud();
        return l < 1e-9 ? CERO : new Vector(x / l, y / l);
    }
}
