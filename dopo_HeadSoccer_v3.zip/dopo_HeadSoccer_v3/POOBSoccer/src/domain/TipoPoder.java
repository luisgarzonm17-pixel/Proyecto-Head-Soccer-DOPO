package domain;

// Catálogo de poderes; actúa como fábrica de {@link Poder}. 
public enum TipoPoder {
    CONGELACION("Congelación"), REDUCCION("Reducción"), CONFUSION("Confusión"), LENTITUD("Lentitud");

    private final String etiqueta;
    TipoPoder(String e) { etiqueta = e; }
    public String etiqueta() { return etiqueta; }

    public Poder crear() {
        return switch (this) {
            case CONGELACION -> new Congelacion();
            case REDUCCION   -> new Reduccion();
            case CONFUSION   -> new Confusion();
            case LENTITUD    -> new Lentitud();
        };
    }
    @Override public String toString() { return etiqueta; }
}
