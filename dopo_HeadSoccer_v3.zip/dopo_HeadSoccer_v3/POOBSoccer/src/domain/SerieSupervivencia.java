package domain;

import java.util.List;

// Serie de partidos seguidos contra la máquina; la dificultad sube con cada victoria. 
public class SerieSupervivencia {
    private final String nombre;
    private final FichaPersonaje ficha;
    private int nivel = 1;
    private boolean terminada;

    public SerieSupervivencia(String nombre, FichaPersonaje ficha) {
        if (ficha == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        this.nombre = nombre; this.ficha = ficha;
    }

    public int nivel() { return nivel; }
    public int victorias() { return nivel - 1; }
    public boolean terminada() { return terminada; }

    public Partido nuevoPartido() {
        if (terminada) throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
        List<FichaPersonaje> todos = CatalogoPersonajes.todos();
        FichaPersonaje rival = todos.get((nivel - 1) % todos.size());
        Dificultad dif = nivel <= 2 ? Dificultad.FACIL : nivel <= 4 ? Dificultad.MEDIO : Dificultad.DIFICIL;
        return new Partido(new ConfigPartido(Modalidad.PVSM, TipoPartido.SUPERVIVENCIA, 0,
                nombre, ficha, "Máquina " + nivel, rival, dif));
    }

    // Si el humano ganó pasa al siguiente rival; si perdió, la serie termina. 
    public void registrarResultado(Partido p) {
        if (p.estado() != EstadoPartido.TERMINADO) throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
        if (p.ganador() == Lado.IZQUIERDO) nivel++; else terminada = true;
    }
}
