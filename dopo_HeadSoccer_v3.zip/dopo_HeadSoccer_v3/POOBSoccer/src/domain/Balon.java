package domain;

public class Balon extends Cuerpo {
    public static final double RADIO = 16;
    private static final double GRAVEDAD = 1100, VEL_MAX = 1500;

    public Balon() {
        super(new Vector(Campo.ANCHO / 2, 140), Vector.CERO);
    }

    @Override public double radio() { return RADIO; }

    // El balón cae desde el centro de la cancha. 
    public void reiniciar() {
        fijarPos(new Vector(Campo.ANCHO / 2, 140));
        fijarVel(Vector.CERO);
    }

    public void mover(double dt) {
        Vector v = vel().mas(new Vector(0, GRAVEDAD * dt));
        if (v.longitud() > VEL_MAX) v = v.normalizado().por(VEL_MAX);
        fijarVel(v);
        fijarPos(pos().mas(v.por(dt)));
    }
}
