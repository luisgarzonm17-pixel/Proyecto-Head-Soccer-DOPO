package domain;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

// Fachada pública y orquestador del dominio.
// La simulación geométrica está delegada en {@link MotorFisica}; conservar
// esta separación permite agregar reglas o controladores sin mezclar sus
// decisiones con la física.</p>
public class Partido {
    private static final double PASO = 1.0 / 120;          // paso fijo de simulación
    private static final double SEG_CELEBRACION_GOL = 1.5;

    private final ConfigPartido config;
    private final Campo campo = new Campo();
    private final Balon balon = new Balon();
    private final Marcador marcador = new Marcador();
    private final ReglaPartido regla;
    private final Map<Lado, Jugador> jugadores = new EnumMap<>(Lado.class);
    private final List<PartidoListener> oyentes = new ArrayList<>();
    private final MotorFisica motorFisica;
    private EstadoPartido estado = EstadoPartido.PREPARADO;
    private EstadoPartido estadoAntesDePausa;
    private double temporizadorGol;
    private Lado ganador;
    private Lado ultimoToque;

    public Partido(ConfigPartido config) {
        this.config = config;
        this.regla = switch (config.tipo()) {
            case TIEMPO -> new ReglaPorTiempo();
            case GOLES -> new ReglaPorGoles(config.metaGoles());
            case SUPERVIVENCIA -> new ReglaSupervivencia();
        };
        long semilla = System.nanoTime();
        jugadores.put(Lado.IZQUIERDO, new Jugador(config.nombreIzquierdo(), Lado.IZQUIERDO, config.fichaIzquierdo(),
                new ControladorHumano()));
        jugadores.put(Lado.DERECHO, new Jugador(config.nombreDerecho(), Lado.DERECHO, config.fichaDerecho(),
                crearControlador(config.modalidad() == Modalidad.PVSP, semilla + 1)));
        motorFisica = new MotorFisica(campo, balon, jugadores, oyentes);
    }

    private Controlador crearControlador(boolean humano, long semilla) {
        return humano ? new ControladorHumano() : new ControladorMaquina(config.dificultad(), semilla);
    }

    // ---------- consulta ----------
    public ConfigPartido config() { return config; }
    public Campo campo() { return campo; }
    public Balon balon() { return balon; }
    public Marcador marcador() { return marcador; }
    public Jugador jugador(Lado l) { return jugadores.get(l); }
    public EstadoPartido estado() { return estado; }
    public Lado ganador() { return ganador; }
    public Lado ultimoToque() { return ultimoToque; }
    public double tiempoRestante() { return regla.tiempoRestante(); }
    public boolean golDeOro() { return regla.golDeOro(); }
    public String descripcionRegla() { return regla.descripcion(); }
    public boolean usaBalones() { return config.tipo() == TipoPartido.SUPERVIVENCIA; }
    public void agregarOyente(PartidoListener o) { oyentes.add(o); }

    // Restaura una partida previamente guardada después de haber creado su configuración.
// Solo puede usarse inmediatamente después de iniciar el partido.
    public void restaurarEstado(int golesIzquierdo, int golesDerecho,
                                int balonesIzquierdo, int balonesDerecho,
                                double tiempoRestante, boolean golDeOro,
                                double cargaIzquierdo, double cargaDerecho,
                                boolean armadoIzquierdo, boolean armadoDerecho,
                                EstadoPartido estado) {
        marcador.fijarGoles(Lado.IZQUIERDO, golesIzquierdo);
        marcador.fijarGoles(Lado.DERECHO, golesDerecho);
        if (usaBalones()) {
            marcador.fijarBalones(Lado.IZQUIERDO, balonesIzquierdo);
            marcador.fijarBalones(Lado.DERECHO, balonesDerecho);
        }
        if (regla instanceof ReglaPorTiempo tiempo) tiempo.restaurar(tiempoRestante, golDeOro);
        jugador(Lado.IZQUIERDO).restaurarPoder(cargaIzquierdo, armadoIzquierdo);
        jugador(Lado.DERECHO).restaurarPoder(cargaDerecho, armadoDerecho);
        if (estado == EstadoPartido.PAUSADO) {
            estadoAntesDePausa = EstadoPartido.JUGANDO;
            cambiarEstado(EstadoPartido.PAUSADO);
        } else if (estado == EstadoPartido.GOL) {
            temporizadorGol = SEG_CELEBRACION_GOL;
            cambiarEstado(EstadoPartido.GOL);
        }
        else cambiarEstado(EstadoPartido.JUGANDO);
    }

    // ---------- ciclo de vida ----------
    // El partido inicia 0-0, con las barras vacías y los jugadores en su lado. 
    public void iniciar() {
        if (estado != EstadoPartido.PREPARADO) throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
        marcador.reiniciar();
        regla.iniciar(marcador);
        reiniciarRonda();
        cambiarEstado(EstadoPartido.JUGANDO);
    }

    public void pausar() {
        if (estado != EstadoPartido.JUGANDO && estado != EstadoPartido.GOL)
            throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
        estadoAntesDePausa = estado;
        cambiarEstado(EstadoPartido.PAUSADO);
    }

    public void reanudar() {
        if (estado != EstadoPartido.PAUSADO) throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
        cambiarEstado(estadoAntesDePausa);
    }

    // Envía la intención de un jugador humano; se ignora si ese lado lo controla la máquina. 
    public void enviarIntencion(Lado lado, Intencion intencion) {
        if (jugador(lado).controlador() instanceof ControladorHumano h) h.fijar(intencion);
    }

    // ---------- simulación ----------
    // Avanza el partido; un partido pausado o terminado no consume tiempo. 
    public void actualizar(double dt) {
        if (estado == EstadoPartido.GOL) {
            temporizadorGol -= dt;
            if (temporizadorGol <= 0) { reiniciarRonda(); cambiarEstado(EstadoPartido.JUGANDO); }
            return;
        }
        double restante = dt;
        while (restante > 1e-9 && estado == EstadoPartido.JUGANDO) {
            double paso = Math.min(restante, PASO);
            simular(paso);
            restante -= paso;
        }
    }

    private void simular(double dt) {
        regla.alAvanzar(dt, marcador);
        if (regla.terminado(marcador)) { finalizar(); return; }

        MotorFisica.Resultado resultado = motorFisica.avanzar(this, dt);
        if (resultado.ultimoToque() != null) ultimoToque = resultado.ultimoToque();
        if (resultado.arco() != null) registrarGol(resultado.arco().opuesto());
    }

    private void registrarGol(Lado anotador) {
        marcador.registrarGol(anotador);
        regla.alGol(anotador, marcador);
        for (PartidoListener o : oyentes) o.alGol(anotador);
        if (regla.terminado(marcador)) { finalizar(); return; }
        temporizadorGol = SEG_CELEBRACION_GOL;
        cambiarEstado(EstadoPartido.GOL);
    }

    private void finalizar() {
        ganador = regla.ganador(marcador);
        cambiarEstado(EstadoPartido.TERMINADO);
        for (PartidoListener o : oyentes) o.alTerminar(ganador);
    }

    // Después de un gol, personajes y balón vuelven al inicio y el balón cae desde el centro. 
    private void reiniciarRonda() {
        for (Lado l : Lado.values()) jugador(l).personaje().reiniciar(campo.xInicial(l));
        balon.reiniciar();
    }

    private void cambiarEstado(EstadoPartido nuevo) {
        estado = nuevo;
        for (PartidoListener o : oyentes) o.alCambiarEstado(nuevo);
    }
}
