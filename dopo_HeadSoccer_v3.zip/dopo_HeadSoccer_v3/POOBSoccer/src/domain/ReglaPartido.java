package domain;

// Define cómo termina un partido (Strategy). 
public abstract class ReglaPartido {
    // Inicializa cualquier estado propio de la regla. 
    public abstract void iniciar(Marcador marcador);
    // Avanza el reloj o estado propio de la regla. 
    public abstract void alAvanzar(double dt, Marcador marcador);
    // Procesa un gol desde la perspectiva de la regla. 
    public abstract void alGol(Lado anotador, Marcador marcador);
    public abstract boolean terminado(Marcador m);
    public abstract Lado ganador(Marcador m);
    // Segundos restantes, o -1 si el partido no tiene límite de tiempo. 
    public double tiempoRestante() { return -1; }
    public boolean golDeOro() { return false; }
    public abstract String descripcion();
}
