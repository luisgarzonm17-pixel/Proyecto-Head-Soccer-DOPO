package domain;

public enum EstadoPartido { PREPARADO, JUGANDO, GOL, PAUSADO, TERMINADO }
