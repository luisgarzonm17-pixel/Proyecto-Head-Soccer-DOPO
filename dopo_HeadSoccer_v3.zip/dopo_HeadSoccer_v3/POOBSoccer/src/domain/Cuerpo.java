package domain;

// Objeto con posición (centro), velocidad y forma circular dentro de la cancha. 
public abstract class Cuerpo {
    private Vector pos = Vector.CERO;
    private Vector vel = Vector.CERO;
// Construye un cuerpo con posición y velocidad iniciales; las clases derivadas usan esta inicialización.
    protected Cuerpo(Vector pos, Vector vel) {
        this.pos = pos;
        this.vel = vel;
    }
// Construye un cuerpo inmóvil en el origen hasta que la subclase establezca su posición inicial.
    protected Cuerpo() {}

    public Vector pos() { return pos; }
    public Vector vel() { return vel; }
    public void fijarPos(Vector p) { pos = p; }
    public void fijarVel(Vector v) { vel = v; }
    public abstract double radio();
}
