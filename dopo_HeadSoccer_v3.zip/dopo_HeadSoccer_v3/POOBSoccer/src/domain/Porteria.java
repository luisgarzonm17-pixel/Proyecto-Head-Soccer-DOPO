package domain;

// Arco de un lado de la cancha. 
public final class Porteria {
    private final Lado lado;
    private final Hitbox zona;

    Porteria(Lado lado) {
        this.lado = lado;
        double x = lado == Lado.IZQUIERDO ? 0 : Campo.ANCHO - Campo.ANCHO_ARCO;
        zona = new Hitbox(x, Campo.SUELO - Campo.ALTO_ARCO, Campo.ANCHO_ARCO, Campo.ALTO_ARCO);
    }
    public Lado lado() { return lado; }
    public Hitbox zona() { return zona; }
    public double alturaTravesano() { return zona.y(); }

    // Hay gol cuando el balón entra completamente en el arco. 
    public boolean anotado(Balon b) { return zona.contieneCompleto(b.pos(), b.radio()); }

    boolean estaSobreTravesano(Balon b) {
        return b.pos().x() >= zona.x() && b.pos().x() <= zona.x() + zona.ancho();
    }
}
