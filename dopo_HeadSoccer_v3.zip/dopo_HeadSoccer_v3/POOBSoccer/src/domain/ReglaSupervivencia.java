package domain;

// Se juega con balones: cada gol le quita un balón al rival; pierde quien se quede sin balones. 
public class ReglaSupervivencia extends ReglaPartido {
    public static final int BALONES_INICIALES = 3;
    private final int balones;

    public ReglaSupervivencia() { this(BALONES_INICIALES); }
    public ReglaSupervivencia(int balones) { this.balones = balones; }

    @Override public void iniciar(Marcador m) { m.fijarBalones(balones); }
    @Override public void alAvanzar(double dt, Marcador m) {
        if (dt < 0 || m == null)
            throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
    }
    @Override public void alGol(Lado anotador, Marcador m) { m.quitarBalon(anotador.opuesto()); }
    @Override public boolean terminado(Marcador m) {
        return m.balones(Lado.IZQUIERDO) == 0 || m.balones(Lado.DERECHO) == 0;
    }
    @Override public Lado ganador(Marcador m) {
        if (!terminado(m)) return null;
        return m.balones(Lado.IZQUIERDO) == 0 ? Lado.DERECHO : Lado.IZQUIERDO;
    }
    @Override public String descripcion() { return "Supervivencia: " + balones + " balones"; }
}
