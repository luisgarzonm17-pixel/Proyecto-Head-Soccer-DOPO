package domain;

// 60 s; gana quien tenga más goles. Si hay empate se juega gol de oro. 
public class ReglaPorTiempo extends ReglaPartido {
    public static final double DURACION = 60;
    private double restante = DURACION;
    private boolean oro;

    @Override public void iniciar(Marcador m) { restante = DURACION; oro = false; }

    @Override public void alAvanzar(double dt, Marcador m) {
        if (oro) return;
        restante = Math.max(0, restante - dt);
        if (restante == 0 && m.lider() == null) oro = true;
    }
    @Override public void alGol(Lado anotador, Marcador m) {
        if (anotador == null || m == null)
            throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
    }
    @Override public boolean terminado(Marcador m) { return oro ? m.lider() != null : restante <= 0; }
    @Override public Lado ganador(Marcador m) { return terminado(m) ? m.lider() : null; }
    @Override public double tiempoRestante() { return restante; }
    @Override public boolean golDeOro() { return oro; }
    @Override public String descripcion() { return "Por tiempo: " + (int) DURACION + " s"; }
    // Restaura el reloj y el estado de gol de oro al abrir una partida. 
    void restaurar(double tiempo, boolean golDeOro) {
        if (tiempo < 0 || tiempo > DURACION) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        this.restante = tiempo;
        this.oro = golDeOro;
    }
}
