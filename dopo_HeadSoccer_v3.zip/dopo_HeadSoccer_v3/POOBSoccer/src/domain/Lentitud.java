package domain;

// Poder Lentitud: aplica el efecto LENTO durante 6.0 s. 
public class Lentitud extends Poder {
    public Lentitud() { super(TipoPoder.LENTITUD, TipoEfecto.LENTO, 6.0); }
}
