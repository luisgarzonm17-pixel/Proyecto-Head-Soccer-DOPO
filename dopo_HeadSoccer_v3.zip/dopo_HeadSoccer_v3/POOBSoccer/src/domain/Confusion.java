package domain;

// Poder Confusion: aplica el efecto CONFUNDIDO durante 6.0 s. 
public class Confusion extends Poder {
    public Confusion() { super(TipoPoder.CONFUSION, TipoEfecto.CONFUNDIDO, 6.0); }
}
