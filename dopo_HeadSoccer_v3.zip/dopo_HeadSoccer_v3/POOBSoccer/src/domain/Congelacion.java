package domain;

// Poder Congelacion: aplica el efecto CONGELADO durante 3.0 s. 
public class Congelacion extends Poder {
    public Congelacion() { super(TipoPoder.CONGELACION, TipoEfecto.CONGELADO, 3.0); }
}
