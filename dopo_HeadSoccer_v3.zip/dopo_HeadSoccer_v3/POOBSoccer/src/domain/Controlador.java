package domain;

// Estrategia que decide las acciones de un Jugador (Strategy). 
public interface Controlador {
    Intencion decidir(Partido partido, Jugador yo, double dt);
}
