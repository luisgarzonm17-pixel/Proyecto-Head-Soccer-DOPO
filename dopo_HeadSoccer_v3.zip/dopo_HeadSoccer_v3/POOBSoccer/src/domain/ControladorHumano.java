package domain;

// Recibe desde fuera (la interfaz) la intención del jugador humano. 
public class ControladorHumano implements Controlador {
    private Intencion actual = Intencion.NINGUNA;

    public void fijar(Intencion intencion) { actual = intencion == null ? Intencion.NINGUNA : intencion; }
    @Override public Intencion decidir(Partido partido, Jugador yo, double dt) { return actual; }
}
