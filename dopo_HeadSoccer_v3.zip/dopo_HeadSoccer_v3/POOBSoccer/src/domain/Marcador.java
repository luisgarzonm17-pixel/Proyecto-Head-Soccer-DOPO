package domain;

import java.util.EnumMap;
import java.util.Map;

// Goles y balones restantes de cada lado. 
public class Marcador {
    private final Map<Lado, Integer> goles = new EnumMap<>(Lado.class);
    private final Map<Lado, Integer> balones = new EnumMap<>(Lado.class);

    public Marcador() {
        for (Lado l : Lado.values()) {
            goles.put(l, 0);
            balones.put(l, 0);
        }
    }

    public void reiniciar() {
        for (Lado l : Lado.values()) { goles.put(l, 0); balones.put(l, 0); }
    }
    public int goles(Lado l) { return goles.get(l); }
    public int balones(Lado l) { return balones.get(l); }
    // Suma 1 punto al lado indicado. Un autogol se registra llamando con el lado rival. 
    public void registrarGol(Lado anotador) { goles.merge(anotador, 1, Integer::sum); }
    // Establece el marcador al restaurar una partida guardada. 
    public void fijarGoles(Lado lado, int cantidad) {
        if (cantidad < 0) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        goles.put(lado, cantidad);
    }
    public void fijarBalones(int n) { for (Lado l : Lado.values()) balones.put(l, n); }
    // Establece los balones restantes de un lado al restaurar una partida. 
    public void fijarBalones(Lado lado, int cantidad) {
        if (cantidad < 0) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        balones.put(lado, cantidad);
    }
    public void quitarBalon(Lado l) { balones.merge(l, -1, (a, b) -> Math.max(0, a + b)); }
    public Lado lider() {
        int i = goles(Lado.IZQUIERDO), d = goles(Lado.DERECHO);
        return i == d ? null : (i > d ? Lado.IZQUIERDO : Lado.DERECHO);
    }
}
