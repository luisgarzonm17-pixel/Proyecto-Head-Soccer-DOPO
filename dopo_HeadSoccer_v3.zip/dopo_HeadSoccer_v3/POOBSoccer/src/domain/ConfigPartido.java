package domain;

// Configuración validada de un partido. 
public record ConfigPartido(Modalidad modalidad, TipoPartido tipo, int metaGoles,
                            String nombreIzquierdo, FichaPersonaje fichaIzquierdo,
                            String nombreDerecho, FichaPersonaje fichaDerecho,
                            Dificultad dificultad) {
    public ConfigPartido {
        if (modalidad == null || tipo == null || fichaIzquierdo == null || fichaDerecho == null)
            throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        if (tipo == TipoPartido.SUPERVIVENCIA && modalidad != Modalidad.PVSM)
            throw new POOBSoccerException(POOBSoccerException.SUPERVIVENCIA_SOLO_PVSM);
        if (tipo == TipoPartido.GOLES && metaGoles != 3 && metaGoles != 5 && metaGoles != 7)
            throw new POOBSoccerException(POOBSoccerException.META_INVALIDA);
        if (nombreIzquierdo == null || nombreIzquierdo.isBlank()) nombreIzquierdo = "Jugador 1";
        if (nombreDerecho == null || nombreDerecho.isBlank())
            nombreDerecho = modalidad == Modalidad.PVSP ? "Jugador 2" : "Máquina";
        if (dificultad == null) dificultad = Dificultad.MEDIO;
    }
}
