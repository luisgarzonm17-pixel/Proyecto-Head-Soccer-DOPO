package domain;

// Calidad de la máquina: tiempo de reacción (s) y error de posicionamiento (px). 
public enum Dificultad {
    FACIL("Fácil", 0.30, 80), MEDIO("Medio", 0.15, 40), DIFICIL("Difícil", 0.06, 12);

    private final String etiqueta; private final double reaccion, error;
    Dificultad(String e, double r, double er) { etiqueta = e; reaccion = r; error = er; }
    public double reaccion() { return reaccion; }
    public double error() { return error; }
    @Override public String toString() { return etiqueta; }
}
