package domain;

// Poder Reduccion: aplica el efecto REDUCIDO durante 6.0 s. 
public class Reduccion extends Poder {
    public Reduccion() { super(TipoPoder.REDUCCION, TipoEfecto.REDUCIDO, 6.0); }
}
