package domain;

import java.util.List;
import java.util.Map;

// Motor interno que ejecuta un paso de la simulación física.
// abstracción pública. Su única responsabilidad es actualizar cuerpos,
// resolver contactos y detectar si el balón entró en una portería. De esta
// forma {@link Partido} conserva el control del ciclo de vida, pero no tiene
// que conocer cada detalle geométrico.</p>
final class MotorFisica {
    private static final double REST_PERSONAJE = 0.8;
    private static final double ALCANCE_PATADA = 26;

    private final Campo campo;
    private final Balon balon;
    private final Map<Lado, Jugador> jugadores;
    private final List<PartidoListener> oyentes;

    MotorFisica(Campo campo, Balon balon, Map<Lado, Jugador> jugadores,
                List<PartidoListener> oyentes) {
        this.campo = campo;
        this.balon = balon;
        this.jugadores = jugadores;
        this.oyentes = oyentes;
    }

    // Ejecuta un paso completo: decisiones, movimiento, contactos y rebotes.
    Resultado avanzar(Partido partido, double dt) {
        Jugador izquierdo = jugadores.get(Lado.IZQUIERDO);
        Jugador derecho = jugadores.get(Lado.DERECHO);
        actualizarJugador(partido, izquierdo, dt);
        actualizarJugador(partido, derecho, dt);
        separar(izquierdo.personaje(), derecho.personaje());

        balon.mover(dt);
        Lado ultimoToque = interactuar(izquierdo, derecho);
        Lado segundoToque = interactuar(derecho, izquierdo);
        if (segundoToque != null) ultimoToque = segundoToque;
        campo.contenerBalon(balon, dt);

        return new Resultado(ultimoToque, campo.arcoConGol(balon));
    }

    private void actualizarJugador(Partido partido, Jugador jugador, double dt) {
        jugador.cargar(dt);
        Intencion intencion = jugador.controlador().decidir(partido, jugador, dt);
        jugador.personaje().actuar(intencion, dt);
        if (intencion.poder() && !jugador.personaje().inmovilizado()) jugador.armar();
        jugador.personaje().avanzar(dt);
        campo.contenerPersonaje(jugador.personaje());
    }

    private void separar(Personaje a, Personaje b) {
        Vector diferencia = b.pos().menos(a.pos());
        double distancia = diferencia.longitud();
        double minima = a.radio() + b.radio();
        if (distancia >= minima) return;

        Vector normal = distancia < 1e-6 ? new Vector(1, 0) : diferencia.por(1 / distancia);
        Vector movimiento = normal.por((minima - distancia) / 2);
        a.fijarPos(a.pos().menos(movimiento));
        b.fijarPos(b.pos().mas(movimiento));
        campo.contenerPersonaje(a);
        campo.contenerPersonaje(b);
    }

    // Resuelve el contacto de un jugador con el balón y con su rival.
// el balón, luego la patada y finalmente el posible aturdimiento del rival.
// Ese orden conserva la sensación de control del juego.</p>
    private Lado interactuar(Jugador jugador, Jugador rival) {
        Personaje personaje = jugador.personaje();
        Vector diferencia = balon.pos().menos(personaje.pos());
        double distancia = diferencia.longitud();
        double contacto = personaje.radio() + balon.radio();
        boolean golpeo = false;

        if (distancia < contacto) {
            Vector normal = distancia < 1e-6 ? new Vector(0, -1) : diferencia.por(1 / distancia);
            balon.fijarPos(personaje.pos().mas(normal.por(contacto)));
            double velocidadNormal = balon.vel().menos(personaje.vel()).punto(normal);
            if (velocidadNormal < 0) {
                balon.fijarVel(balon.vel().menos(normal.por((1 + REST_PERSONAJE) * velocidadNormal)));
            }
            golpearBalon(jugador, rival);
            golpeo = true;
            diferencia = balon.pos().menos(personaje.pos());
            distancia = diferencia.longitud();
        }

        if (personaje.pateando() && distancia <= contacto + ALCANCE_PATADA
                && personaje.consumirPatadaEnBalon()) {
            double lateral = Math.max(Math.abs(diferencia.x() / Math.max(distancia, 1e-6)), 0.55)
                    * jugador.lado().direccionAtaque();
            double vertical = diferencia.y() / Math.max(distancia, 1e-6) - 0.45;
            Vector direccion = new Vector(lateral, vertical).normalizado();
            balon.fijarVel(direccion.por(personaje.fuerzaPatada()).mas(personaje.vel().por(0.3)));
            golpearBalon(jugador, rival);
            golpeo = true;
        }

        Personaje rivalPersonaje = rival.personaje();
        double distanciaRival = rivalPersonaje.pos().menos(personaje.pos()).longitud();
        if (personaje.pateando()
                && distanciaRival <= personaje.radio() + rivalPersonaje.radio() + ALCANCE_PATADA
                && personaje.consumirPatadaEnRival()) {
            rivalPersonaje.aplicarEfecto(TipoEfecto.ATURDIDO, Personaje.SEG_ATURDIMIENTO);
        }
        return golpeo ? jugador.lado() : null;
    }

    private void golpearBalon(Jugador jugador, Jugador rival) {
        if (jugador.poderArmado()) {
            Poder poder = jugador.dispararPoder(rival.personaje());
            for (PartidoListener oyente : oyentes) oyente.alUsarPoder(jugador, poder);
        }
    }

    record Resultado(Lado ultimoToque, Lado arco) {}
}
