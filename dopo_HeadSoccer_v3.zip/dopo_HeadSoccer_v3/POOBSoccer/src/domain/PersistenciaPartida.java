package domain;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

// Guarda y abre el estado restaurable de una partida.
// configuración, marcador, reloj, balones, carga de poderes y posiciones.
// No guarda series: una serie de supervivencia conserva su propio nivel en
// memoria y comienza una nueva apertura como partida independiente.</p>
public final class PersistenciaPartida {
    private PersistenciaPartida() {}

    // Nombre de extensión usado por los cuadros de selección de archivo. 
    public static final String EXTENSION = "poobsoccer";

    // Guarda una partida iniciada en un archivo.
    public static void guardar(File archivo, Partido partido) throws IOException {
        if (partido == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        if (partido.estado() == EstadoPartido.PREPARADO || partido.estado() == EstadoPartido.TERMINADO)
            throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);

        Properties p = new Properties();
        ConfigPartido c = partido.config();
        p.setProperty("version", "1");
        p.setProperty("modalidad", c.modalidad().name());
        p.setProperty("tipo", c.tipo().name());
        p.setProperty("metaGoles", Integer.toString(c.metaGoles()));
        p.setProperty("nombreIzquierdo", c.nombreIzquierdo());
        p.setProperty("fichaIzquierdo", c.fichaIzquierdo().nombre());
        p.setProperty("nombreDerecho", c.nombreDerecho());
        p.setProperty("fichaDerecho", c.fichaDerecho().nombre());
        p.setProperty("dificultad", c.dificultad().name());
        p.setProperty("estado", partido.estado().name());
        p.setProperty("golesIzquierdo", Integer.toString(partido.marcador().goles(Lado.IZQUIERDO)));
        p.setProperty("golesDerecho", Integer.toString(partido.marcador().goles(Lado.DERECHO)));
        p.setProperty("balonesIzquierdo", Integer.toString(partido.marcador().balones(Lado.IZQUIERDO)));
        p.setProperty("balonesDerecho", Integer.toString(partido.marcador().balones(Lado.DERECHO)));
        p.setProperty("tiempo", Double.toString(partido.tiempoRestante()));
        p.setProperty("golDeOro", Boolean.toString(partido.golDeOro()));

        guardarJugador(p, "Izquierdo", partido.jugador(Lado.IZQUIERDO));
        guardarJugador(p, "Derecho", partido.jugador(Lado.DERECHO));
        guardarCuerpo(p, "balon", partido.balon());

        try (FileOutputStream salida = new FileOutputStream(archivo)) {
            p.store(salida, "POOBSoccer partida");
        }
    }

    // Abre una partida guardada y la deja iniciada o pausada según el estado original.
    public static Partido abrir(File archivo) throws IOException {
        Properties p = new Properties();
        try (FileInputStream entrada = new FileInputStream(archivo)) {
            p.load(entrada);
        }
        if (!"1".equals(p.getProperty("version"))) {
            throw new POOBSoccerException("Versión de partida no compatible.");
        }

        Modalidad modalidad;
        TipoPartido tipo;
        Dificultad dificultad;
        try {
            modalidad = Modalidad.valueOf(p.getProperty("modalidad"));
            tipo = TipoPartido.valueOf(p.getProperty("tipo"));
            dificultad = Dificultad.valueOf(p.getProperty("dificultad"));
        } catch (RuntimeException ex) {
            throw new POOBSoccerException("La partida contiene datos no válidos.");
        }

        FichaPersonaje izquierda = buscarFicha(p.getProperty("fichaIzquierdo"));
        FichaPersonaje derecha = buscarFicha(p.getProperty("fichaDerecho"));
        int meta = entero(p, "metaGoles");
        ConfigPartido config = new ConfigPartido(modalidad, tipo, meta,
                p.getProperty("nombreIzquierdo"), izquierda,
                p.getProperty("nombreDerecho"), derecha, dificultad);
        Partido partido = new Partido(config);
        partido.iniciar();
        partido.restaurarEstado(
                entero(p, "golesIzquierdo"), entero(p, "golesDerecho"),
                entero(p, "balonesIzquierdo"), entero(p, "balonesDerecho"),
                decimal(p, "tiempo"), Boolean.parseBoolean(p.getProperty("golDeOro")),
                decimal(p, "cargaIzquierdo"), decimal(p, "cargaDerecho"),
                Boolean.parseBoolean(p.getProperty("armadoIzquierdo")),
                Boolean.parseBoolean(p.getProperty("armadoDerecho")),
                leerEstado(p));

        restaurarCuerpo(p, "Izquierdo", partido.jugador(Lado.IZQUIERDO).personaje());
        restaurarCuerpo(p, "Derecho", partido.jugador(Lado.DERECHO).personaje());
        restaurarCuerpo(p, "balon", partido.balon());
        return partido;
    }

    private static void guardarJugador(Properties p, String sufijo, Jugador jugador) {
        p.setProperty("carga" + sufijo, Double.toString(jugador.carga()));
        p.setProperty("armado" + sufijo, Boolean.toString(jugador.poderArmado()));
        guardarCuerpo(p, sufijo, jugador.personaje());
    }

    private static void guardarCuerpo(Properties p, String prefijo, Cuerpo cuerpo) {
        p.setProperty("x" + prefijo, Double.toString(cuerpo.pos().x()));
        p.setProperty("y" + prefijo, Double.toString(cuerpo.pos().y()));
        p.setProperty("vx" + prefijo, Double.toString(cuerpo.vel().x()));
        p.setProperty("vy" + prefijo, Double.toString(cuerpo.vel().y()));
    }

    private static void restaurarCuerpo(Properties p, String prefijo, Cuerpo cuerpo) {
        cuerpo.fijarPos(new Vector(decimal(p, "x" + prefijo), decimal(p, "y" + prefijo)));
        cuerpo.fijarVel(new Vector(decimal(p, "vx" + prefijo), decimal(p, "vy" + prefijo)));
    }

    private static FichaPersonaje buscarFicha(String nombre) {
        if (nombre == null) throw new POOBSoccerException(POOBSoccerException.DATOS_INCOMPLETOS);
        for (FichaPersonaje ficha : CatalogoPersonajes.todos())
            if (ficha.nombre().equals(nombre)) return ficha;
        throw new POOBSoccerException("Personaje guardado no existe en el catálogo.");
    }

    private static EstadoPartido leerEstado(Properties p) {
        try {
            EstadoPartido estado = EstadoPartido.valueOf(p.getProperty("estado"));
            if (estado == EstadoPartido.PREPARADO || estado == EstadoPartido.TERMINADO)
                throw new POOBSoccerException(POOBSoccerException.ESTADO_INVALIDO);
            return estado;
        } catch (RuntimeException ex) {
            throw new POOBSoccerException("Estado de partida no válido.");
        }
    }

    private static int entero(Properties p, String clave) {
        try { return Integer.parseInt(p.getProperty(clave)); }
        catch (RuntimeException ex) { throw new POOBSoccerException("Dato entero incompleto: " + clave); }
    }

    private static double decimal(Properties p, String clave) {
        try { return Double.parseDouble(p.getProperty(clave)); }
        catch (RuntimeException ex) { throw new POOBSoccerException("Dato numérico incompleto: " + clave); }
    }
}
