package domain;

import java.io.File;
import java.util.List;

// Pruebas sin dependencias externas: ejecutar con `java -cp out domain.PruebasDominio`. 
public class PruebasDominio {
    static int ok = 0, fallos = 0;
    static final FichaPersonaje A = CatalogoPersonajes.todos().get(0), B = CatalogoPersonajes.todos().get(1);

    static void check(String nombre, boolean cond) {
        if (cond) ok++; else { fallos++; System.out.println("FALLO: " + nombre); }
    }
    static void lanza(String nombre, Runnable r) {
        try { r.run(); fallos++; System.out.println("FALLO (no lanzó): " + nombre); }
        catch (POOBSoccerException e) { ok++; }
    }
    static Partido partido(Modalidad m, TipoPartido t, int meta) {
        Partido p = new Partido(new ConfigPartido(m, t, meta, "A", A, "B", B, Dificultad.DIFICIL));
        p.iniciar();
        return p;
    }
    static void correr(Partido p, double segundos) {
        for (double t = 0; t < segundos && p.estado() != EstadoPartido.TERMINADO; t += 1.0 / 60) p.actualizar(1.0 / 60);
    }
    // Coloca el balón dentro del arco del lado indicado. 
    static void balonEnArco(Partido p, Lado arco) {
        double x = arco == Lado.IZQUIERDO ? 40 : Campo.ANCHO - 40;
        p.balon().fijarPos(new Vector(x, Campo.SUELO - 60));
        p.balon().fijarVel(Vector.CERO);
    }

    public static void main(String[] args) {
        // --- validaciones ---
        lanza("supervivencia solo PvsM", () -> new ConfigPartido(Modalidad.PVSP, TipoPartido.SUPERVIVENCIA, 0, "a", A, "b", B, null));
        lanza("meta de goles inválida", () -> new ConfigPartido(Modalidad.PVSP, TipoPartido.GOLES, 4, "a", A, "b", B, null));
        lanza("estadística fuera de rango", () -> new FichaPersonaje("x", "y", 6, 1, 1, TipoPoder.CONGELACION));
        lanza("iniciar dos veces", () -> { Partido p = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0); p.iniciar(); });

        // --- estado inicial ---
        Partido p = partido(Modalidad.PVSP, TipoPartido.GOLES, 3);
        check("marcador 0-0", p.marcador().goles(Lado.IZQUIERDO) == 0 && p.marcador().goles(Lado.DERECHO) == 0);
        check("barras vacías", p.jugador(Lado.IZQUIERDO).carga() == 0 && p.jugador(Lado.DERECHO).carga() == 0);
        check("jugadores en su lado", p.jugador(Lado.IZQUIERDO).personaje().pos().x() < Campo.ANCHO / 2
                && p.jugador(Lado.DERECHO).personaje().pos().x() > Campo.ANCHO / 2);

        // --- gol y autogol ---
        balonEnArco(p, Lado.DERECHO); p.actualizar(1.0 / 60);
        check("gol en arco rival suma al izquierdo", p.marcador().goles(Lado.IZQUIERDO) == 1);
        check("estado GOL tras gol", p.estado() == EstadoPartido.GOL);
        correr(p, 2);
        check("tras el gol vuelve a JUGANDO", p.estado() == EstadoPartido.JUGANDO);
        check("balón reiniciado al centro", Math.abs(p.balon().pos().x() - Campo.ANCHO / 2) < 5);
        balonEnArco(p, Lado.IZQUIERDO); p.actualizar(1.0 / 60);   // autogol del izquierdo
        check("gol en arco propio suma al rival", p.marcador().goles(Lado.DERECHO) == 1);

        // --- por goles: termina al llegar a la meta ---
        correr(p, 2);
        for (int i = 0; i < 2; i++) { balonEnArco(p, Lado.DERECHO); p.actualizar(1.0 / 60); correr(p, 2); }
        check("por goles termina a 3", p.estado() == EstadoPartido.TERMINADO && p.ganador() == Lado.IZQUIERDO);

        // --- pausa ---
        Partido q = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0);
        q.pausar();
        double t0 = q.tiempoRestante(); q.actualizar(1.0);
        check("pausado no avanza el tiempo", q.tiempoRestante() == t0 && q.estado() == EstadoPartido.PAUSADO);
        q.reanudar();
        q.actualizar(1.0);
        check("reanudado avanza el tiempo", q.tiempoRestante() < t0);
        lanza("reanudar sin pausa", q::reanudar);

        // --- por tiempo: empate => gol de oro ---
        Partido r = partido(Modalidad.PVSM, TipoPartido.TIEMPO, 0);
        for (int i = 0; i < 300 * 60 && r.tiempoRestante() > 0; i++) r.actualizar(1.0 / 60);
        if (r.marcador().lider() == null) {
            check("empate entra en gol de oro", r.golDeOro() && r.estado() != EstadoPartido.TERMINADO);
            r.actualizar(2.0);
            balonEnArco(r, Lado.IZQUIERDO); r.actualizar(1.0 / 60);
            check("gol de oro termina el partido", r.estado() == EstadoPartido.TERMINADO && r.ganador() == Lado.DERECHO);
        } else check("termina con más goles", r.estado() == EstadoPartido.TERMINADO);

        // --- empate forzado => gol de oro ---
        Partido e = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0);
        balonEnArco(e, Lado.DERECHO); e.actualizar(1.0 / 60); correr(e, 2);
        balonEnArco(e, Lado.IZQUIERDO); e.actualizar(1.0 / 60); correr(e, 2);
        for (int i = 0; i < 70 * 60 && !e.golDeOro() && e.estado() != EstadoPartido.TERMINADO; i++) e.actualizar(1.0 / 60);
        check("1-1 al terminar el tiempo entra en gol de oro", e.golDeOro() && e.estado() == EstadoPartido.JUGANDO);
        balonEnArco(e, Lado.DERECHO); e.actualizar(1.0 / 60);
        check("el primero que anota en gol de oro gana", e.estado() == EstadoPartido.TERMINADO && e.ganador() == Lado.IZQUIERDO);

        // --- supervivencia ---
        Partido s = partido(Modalidad.PVSM, TipoPartido.SUPERVIVENCIA, 0);
        check("3 balones iniciales", s.marcador().balones(Lado.IZQUIERDO) == 3 && s.marcador().balones(Lado.DERECHO) == 3);
        balonEnArco(s, Lado.DERECHO); s.actualizar(1.0 / 60);
        check("gol quita balón al rival", s.marcador().balones(Lado.DERECHO) == 2 && s.marcador().balones(Lado.IZQUIERDO) == 3);
        for (int i = 0; i < 2; i++) { correr(s, 2); balonEnArco(s, Lado.DERECHO); s.actualizar(1.0 / 60); }
        check("sin balones pierde", s.estado() == EstadoPartido.TERMINADO && s.ganador() == Lado.IZQUIERDO);
        SerieSupervivencia serie = new SerieSupervivencia("Yo", A);
        serie.registrarResultado(s);
        check("serie avanza de nivel al ganar", serie.nivel() == 2 && !serie.terminada());

        // --- poderes ---
        Partido w = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0);
        Jugador izq = w.jugador(Lado.IZQUIERDO);
        w.enviarIntencion(Lado.IZQUIERDO, new Intencion(false, false, false, false, true));
        correr(w, 1);
        check("poder no se arma con barra incompleta", !izq.poderArmado());
        correr(w, Jugador.SEGUNDOS_CARGA);
        check("barra se llena con el tiempo", izq.carga() >= 1.0 || izq.poderArmado());
        w.actualizar(1.0 / 60);
        check("poder se arma con barra llena", izq.poderArmado() && izq.carga() == 0);
        Personaje rivalP = w.jugador(Lado.DERECHO).personaje();
        w.balon().fijarPos(izq.personaje().pos().mas(new Vector(izq.personaje().radio() + 5, 0)));
        w.balon().fijarVel(Vector.CERO);
        w.actualizar(1.0 / 60);
        check("al golpear el balón se congela al rival (Canadá)", rivalP.tiene(TipoEfecto.CONGELADO) && !izq.poderArmado());
        double x0 = rivalP.pos().x();
        w.enviarIntencion(Lado.DERECHO, new Intencion(true, false, false, false, false));
        correr(w, 0.5);
        check("congelado no se mueve", Math.abs(rivalP.pos().x() - x0) < 1e-6);
        correr(w, 3.5);
        check("el efecto termina", !rivalP.tiene(TipoEfecto.CONGELADO));

        // --- efectos individuales ---
        Personaje pj = new Personaje(B);
        pj.reiniciar(300);
        double r0 = pj.radio();
        TipoPoder.REDUCCION.crear().aplicar(pj);
        check("reducción encoge", pj.radio() < r0);
        pj.reiniciar(300);
        TipoPoder.CONFUSION.crear().aplicar(pj);
        pj.actuar(new Intencion(false, true, false, false, false), 0.01);
        check("confusión invierte controles", pj.vel().x() < 0);

        // --- aturdimiento por patada (3 s) e inmunidad posterior ---
        Partido k = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0);
        Personaje a = k.jugador(Lado.IZQUIERDO).personaje(), b = k.jugador(Lado.DERECHO).personaje();
        b.fijarPos(a.pos().mas(new Vector(a.radio() + b.radio() + 5, 0)));
        k.enviarIntencion(Lado.IZQUIERDO, new Intencion(false, false, false, true, false));
        k.actualizar(1.0 / 30);
        check("patada al rival lo aturde", b.tiene(TipoEfecto.ATURDIDO));

        // --- solo existen las modalidades PvsP y PvsM ---
        check("solo existen PvsP y PvsM", Modalidad.values().length == 2);

        // --- persistencia ---
        Partido guardable = partido(Modalidad.PVSP, TipoPartido.TIEMPO, 0);
        balonEnArco(guardable, Lado.DERECHO); guardable.actualizar(1.0 / 60); correr(guardable, 2);
        guardable.pausar();
        File temporal = new File(System.getProperty("java.io.tmpdir"), "poobsoccer-prueba.poobsoccer");
        try {
            PersistenciaPartida.guardar(temporal, guardable);
            Partido abierta = PersistenciaPartida.abrir(temporal);
            check("guardar y abrir conserva marcador", abierta.marcador().goles(Lado.IZQUIERDO) == 1);
            check("guardar y abrir conserva pausa", abierta.estado() == EstadoPartido.PAUSADO);
        } catch (Exception ex) {
            fallos++;
            System.out.println("FALLO (persistencia): " + ex.getMessage());
        } finally {
            temporal.delete();
        }

        System.out.println(ok + " verificaciones correctas, " + fallos + " fallos");
        if (fallos > 0) System.exit(1);
    }
}
