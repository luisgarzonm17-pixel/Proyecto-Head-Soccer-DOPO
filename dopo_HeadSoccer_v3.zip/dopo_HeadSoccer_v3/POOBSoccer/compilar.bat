@echo off
rem Compila y ejecuta POOBSoccer (requiere JDK 17 o superior)
if not exist out mkdir out
javac -d out src\domain\*.java src\presentation\*.java test\domain\*.java || exit /b 1
if "%1"=="test" (java -cp out domain.PruebasDominio) else (java -cp out presentation.POOBSoccer)
